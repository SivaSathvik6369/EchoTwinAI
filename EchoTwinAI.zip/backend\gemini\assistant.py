import os
import json
import google.generativeai as genai

class GeminiAssistant:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.model_name = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
        self.is_configured = False
        
        if self.api_key:
            try:
                genai.configure(api_key=self.api_key)
                self.model = genai.GenerativeModel(self.model_name)
                self.is_configured = True
                print(f"Gemini AI Assistant initialized using model: {self.model_name}")
            except Exception as e:
                print(f"Error configuring Gemini client: {e}. Running in local rule-based fallback mode.")
        else:
            print("GEMINI_API_KEY environment variable not found. Chat running in simulated AI response mode.")

    def generate_incident_explanation(self, graph_data, user_query):
        """
        Sends the current graph summary (nodes/edges count, services involved, timestamps)
        and the user query to Gemini to generate a response.
        """
        # Compress graph data into a text summary for context
        nodes = graph_data.get("nodes", [])
        edges = graph_data.get("edges", [])
        
        incidents = [n for n in nodes if n["type"] == "incident"]
        commits = [n for n in nodes if n["type"] == "commit"]
        tickets = [n for n in nodes if n["type"] == "ticket"]
        support = [n for n in nodes if n["type"] == "support"]
        servers = [n for n in nodes if n["type"] == "server"]
        services = [n for n in nodes if n["type"] == "service"]
        
        # Build textual representation
        context_summary = f"""
EchoTwin AI Incident Graph Context:
- Services present: {', '.join([s['data']['title'] for s in services])}
- Total Incidents: {len(incidents)}
  List: {', '.join([f"{i['id']} ({i['data']['severity']}): {i['data']['title']} on {i['data']['service']}" for i in incidents])}
- Total Commits: {len(commits)}
  List: {', '.join([f"{c['id']} by {c['data']['author']}: {c['data']['title']} changing {c['data']['files_changed']}" for c in commits])}
- Total Jira Tickets: {len(tickets)}
  List: {', '.join([f"{t['id']} ({t['data']['priority']}): {t['data']['title']} ({t['data']['status']})" for t in tickets])}
- Customer Support tickets: {len(support)}
  List: {', '.join([f"{s['id']} Category '{s['data']['category']}': {s['data']['title']}" for s in support])}
- Correlation relationships (Edges): {len(edges)}
        """

        prompt = f"""
You are the EchoTwin AI Assistant, an expert site reliability engineer (SRE) and software architect.
You have access to a cross-domain correlation graph linking code changes (commits), server stats, incidents, customer complaints, and Jira tickets.

Here is the context of the active incident graph:
{context_summary}

User Question: "{user_query}"

Based on the graph context, provide a professional, concise, and structured explanation. Identify direct correlations (e.g. commits causing spikes or service failures) and recommend mitigation steps.
Limit your response to 3-4 bullet points.
        """

        if self.is_configured:
            try:
                response = self.model.generate_content(prompt)
                return response.text
            except Exception as e:
                return f"Error querying Gemini API ({e}). Falling back to local analysis:\n\n" + self._get_fallback_response(user_query)
        else:
            return self._get_fallback_response(user_query)

    def _get_fallback_response(self, query):
        """
        Rule-based heuristic responses mimicking Gemini AI insights based on the synthetic dataset outages.
        """
        q = query.lower()
        
        if "why" in q or "occur" in q or "root cause" in q or "incident" in q:
            return (
                "**Root Cause Analysis (EchoTwin AI Correlated Insight)**:\n\n"
                "* **Inciting Incident**: At 11:45 AM, a Git commit (`b5e91a2`) refactored the database connection pool in `auth-service` configurations.\n"
                "* **Server Spike**: Immediately after, `srv-auth-01` experienced 98% CPU load and active connection exhaustion.\n"
                "* **Cascading Outage**: The `auth-service` crash triggered 504 timeouts in `frontend-web` (`INC-104`), database rollback wait locks, and session token expirations in `payment-gateway` (`INC-105`).\n"
                "* **Resolution**: Revert commit `b5e91a2` to restore connection pool stability, and verify DB lock limits."
            )
            
        elif "risk" in q or "operational" in q or "fail" in q:
            return (
                "**Operational Vulnerabilities & Risks**:\n\n"
                "* **Single Point of Failure**: The `auth-service` acts as a central checkpoint. High dependency edges mean a failure cascades to both checkout gateways and web portals.\n"
                "* **Connection Pool Configuration**: Improper pool sizes under load cause thread lock timeouts (`INC-106`) in `database-core`.\n"
                "* **Monitoring Gaps**: Latency alarms on SMTP (`INC-101`) existed prior but were not correlated to Jira tasks, delaying proactive maintenance."
            )
            
        elif "system" in q or "connect" in q or "central" in q or "node" in q:
            return (
                "**Central Graph Connectivity Analysis**:\n\n"
                "* **Top Node**: `auth-service` is the most connected node, linking to 4 separate event chains (Commit `b5e91a2`, Server `srv-auth-01`, Jira `JIRA-404`, and Incident `INC-103`).\n"
                "* **Edge Clustering**: A high density of correlation edges (temporal + service overlaps) is centered around `auth-service` and `frontend-web`.\n"
                "* **Recommendation**: Introduce API gateways with fallback caching to isolate `frontend-web` when `auth-service` encounters database pool starvation."
            )
            
        elif "similar" in q or "history" in q or "past" in q:
            return (
                "**Historical Anomalies & Similar Incidents**:\n\n"
                "* **July 4th SMTP Issue**: Incident `INC-101` recorded a latency warning on the `email-delivery` service, but was isolated without cascading dependencies.\n"
                "* **July 5th Cache Task**: Ticket `JIRA-403` noted cache size evictions in `auth-service` (Medium priority), potentially correlating with thread exhaustion issues.\n"
                "* **Pattern detected**: Micro-service configuration changes during peak periods are our highest source of server CPU exhaustion events."
            )
            
        else:
            return (
                "**EchoTwin AI System Summary**:\n\n"
                "* I have analyzed the uploaded incident logs, server metrics, customer support chats, Jira tickets, and Git commits.\n"
                "* A prominent outage is detected at 12:00 PM on July 6th, centered around `auth-service` and `frontend-web`.\n"
                "* Ask me: 'Why did this incident occur?', 'What are the biggest operational risks?', or 'Which systems are most connected?' for a deep-dive correlation report."
            )
