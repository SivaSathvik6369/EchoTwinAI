import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import math

class GraphBuilder:
    def __init__(self):
        pass

    def build_network_graph(self, incidents, jira, commits, metrics, support):
        """
        Parses all dataframes, creates React Flow nodes and edges, and correlates events.
        """
        nodes = []
        edges = []
        node_map = {}
        
        # Helper to convert to datetime
        def to_dt(val):
            try:
                if pd.isna(val) or val is None:
                    return None
                return pd.to_datetime(val)
            except Exception:
                return None

        # -------------------------------------------------------------
        # Create Entity & Service Nodes
        # -------------------------------------------------------------
        # Gather all unique services
        services = set()
        for df in [incidents, jira, commits, metrics]:
            if df is not None and "service" in df.columns:
                services.update(df["service"].dropna().unique())
                
        # Gather all unique employees
        employees = {}
        if incidents is not None and "employee_id" in incidents.columns:
            for idx, row in incidents.dropna(subset=["employee_id"]).iterrows():
                employees[row["employee_id"]] = row.get("employee_name", f"Staff ({row['employee_id']})")
        if jira is not None and "assignee_id" in jira.columns:
            for idx, row in jira.dropna(subset=["assignee_id"]).iterrows():
                employees[row["assignee_id"]] = row.get("assignee_name", f"Staff ({row['assignee_id']})")

        # Let's seed employee names for standard IDs if they are missing
        emp_names = {"EMP001": "Alice Smith", "EMP002": "Bob Johnson", "EMP003": "Charlie Brown"}
        for k, v in emp_names.items():
            employees[k] = v

        # Add Service Nodes
        for idx, svc in enumerate(sorted(services)):
            node_id = f"SERVICE-{svc}"
            nodes.append({
                "id": node_id,
                "type": "service",
                "data": {"label": svc.upper(), "title": svc, "description": f"Core component: {svc}"},
                "position": {"x": 100 + idx * 250, "y": 300}
            })
            node_map[node_id] = {"type": "service", "label": svc}

        # Add Employee Nodes
        for idx, (emp_id, emp_name) in enumerate(sorted(employees.items())):
            node_id = f"EMPLOYEE-{emp_id}"
            nodes.append({
                "id": node_id,
                "type": "employee",
                "data": {"label": emp_name, "title": emp_name, "id": emp_id},
                "position": {"x": 200 + idx * 250, "y": 100}
            })
            node_map[node_id] = {"type": "employee", "label": emp_name}

        # -------------------------------------------------------------
        # Create Event Nodes (Incidents, Jira, Commits, Support)
        # -------------------------------------------------------------
        
        # 1. Incident Nodes
        incident_events = []
        if incidents is not None:
            for idx, row in incidents.iterrows():
                node_id = f"INCIDENT-{row['incident_id']}"
                nodes.append({
                    "id": node_id,
                    "type": "incident",
                    "data": {
                        "label": f"Incident: {row['incident_id']}",
                        "title": row["message"],
                        "severity": row["severity"],
                        "service": row["service"],
                        "timestamp": row["timestamp"],
                        "employee_id": row["employee_id"]
                    },
                    "position": {"x": 50 + idx * 180, "y": 500}
                })
                node_map[node_id] = {
                    "type": "incident", 
                    "service": row["service"],
                    "timestamp": to_dt(row["timestamp"]),
                    "employee_id": row["employee_id"],
                    "text": row["message"]
                }
                incident_events.append(node_id)
                
                # Connect Incident to Service
                edges.append({
                    "id": f"edge-inc-svc-{row['incident_id']}",
                    "source": node_id,
                    "target": f"SERVICE-{row['service']}",
                    "label": "affects",
                    "style": {"stroke": "#F87171"}
                })
                
                # Connect Incident to Employee
                if pd.notna(row["employee_id"]):
                    edges.append({
                        "id": f"edge-inc-emp-{row['incident_id']}",
                        "source": node_id,
                        "target": f"EMPLOYEE-{row['employee_id']}",
                        "label": "assigned_to",
                        "style": {"stroke": "#94A3B8", "strokeDasharray": "5,5"}
                    })

        # 2. Jira Ticket Nodes
        jira_events = []
        if jira is not None:
            for idx, row in jira.iterrows():
                node_id = f"JIRA-{row['ticket_id']}"
                nodes.append({
                    "id": node_id,
                    "type": "ticket",
                    "data": {
                        "label": f"Jira: {row['ticket_id']}",
                        "title": row["summary"],
                        "priority": row["priority"],
                        "status": row["status"],
                        "service": row["service"],
                        "timestamp": row["created_time"],
                        "assignee_id": row["assignee_id"]
                    },
                    "position": {"x": 100 + idx * 220, "y": 680}
                })
                node_map[node_id] = {
                    "type": "ticket", 
                    "service": row["service"],
                    "timestamp": to_dt(row["created_time"]),
                    "employee_id": row["assignee_id"],
                    "text": f"{row['summary']} {row['description']}"
                }
                jira_events.append(node_id)
                
                # Connect Jira to Service
                edges.append({
                    "id": f"edge-jira-svc-{row['ticket_id']}",
                    "source": node_id,
                    "target": f"SERVICE-{row['service']}",
                    "label": "references_service",
                    "style": {"stroke": "#60A5FA"}
                })
                
                # Connect Jira to Employee
                if pd.notna(row["assignee_id"]):
                    edges.append({
                        "id": f"edge-jira-emp-{row['ticket_id']}",
                        "source": node_id,
                        "target": f"EMPLOYEE-{row['assignee_id']}",
                        "label": "assignee",
                        "style": {"stroke": "#94A3B8"}
                    })

        # 3. Git Commit Nodes
        commit_events = []
        if commits is not None:
            for idx, row in commits.iterrows():
                node_id = f"COMMIT-{row['commit_sha']}"
                nodes.append({
                    "id": node_id,
                    "type": "commit",
                    "data": {
                        "label": f"Commit: {row['commit_sha']}",
                        "title": row["message"],
                        "author": row["author"],
                        "timestamp": row["timestamp"],
                        "service": row["service"],
                        "files_changed": row["files_changed"]
                    },
                    "position": {"x": 80 + idx * 240, "y": 180}
                })
                
                # Find author EMP ID
                author_emp = "EMP001" if "alice" in row["author"] else ("EMP002" if "bob" in row["author"] else "EMP003")
                node_map[node_id] = {
                    "type": "commit",
                    "service": row["service"],
                    "timestamp": to_dt(row["timestamp"]),
                    "employee_id": author_emp,
                    "text": row["message"]
                }
                commit_events.append(node_id)
                
                # Connect Commit to Service
                edges.append({
                    "id": f"edge-commit-svc-{row['commit_sha']}",
                    "source": node_id,
                    "target": f"SERVICE-{row['service']}",
                    "label": "modifies",
                    "style": {"stroke": "#34D399"}
                })
                
                # Connect Commit to Employee
                edges.append({
                    "id": f"edge-commit-emp-{row['commit_sha']}",
                    "source": node_id,
                    "target": f"EMPLOYEE-{author_emp}",
                    "label": "authored_by",
                    "style": {"stroke": "#34D399", "strokeDasharray": "3,3"}
                })

        # 4. Customer Support Nodes
        support_events = []
        if support is not None:
            for idx, row in support.iterrows():
                node_id = f"SUPPORT-{row['support_id']}"
                # Mapping customer complaint back to likely affected service based on tags or simple heuristic
                inferred_svc = "frontend-web"
                if "auth" in row["message"].lower() or "login" in row["message"].lower():
                    inferred_svc = "auth-service"
                elif "checkout" in row["message"].lower() or "buy" in row["message"].lower() or "pay" in row["message"].lower():
                    inferred_svc = "payment-gateway"
                
                nodes.append({
                    "id": node_id,
                    "type": "support",
                    "data": {
                        "label": f"Support: {row['support_id']}",
                        "title": row["message"],
                        "category": row["category"],
                        "timestamp": row["timestamp"],
                        "status": row["status"],
                        "customer_id": row["customer_id"],
                        "service": inferred_svc
                    },
                    "position": {"x": 300 + idx * 210, "y": 800}
                })
                node_map[node_id] = {
                    "type": "support",
                    "service": inferred_svc,
                    "timestamp": to_dt(row["timestamp"]),
                    "employee_id": row.get("agent_id"),
                    "text": row["message"]
                }
                support_events.append(node_id)
                
                # Connect Support to Service
                edges.append({
                    "id": f"edge-support-svc-{row['support_id']}",
                    "source": node_id,
                    "target": f"SERVICE-{inferred_svc}",
                    "label": "reports_error",
                    "style": {"stroke": "#F59E0B"}
                })
                
                # Connect Support to Employee agent
                if pd.notna(row.get("agent_id")):
                    edges.append({
                        "id": f"edge-support-emp-{row['support_id']}",
                        "source": node_id,
                        "target": f"EMPLOYEE-{row['agent_id']}",
                        "label": "handled_by",
                        "style": {"stroke": "#94A3B8"}
                    })

        # 5. Server Nodes
        if metrics is not None:
            unique_servers = metrics["server_name"].dropna().unique()
            for idx, srv in enumerate(sorted(unique_servers)):
                node_id = f"SERVER-{srv}"
                # Get the service it hosts
                srv_svc = metrics[metrics["server_name"] == srv]["service"].iloc[0]
                
                nodes.append({
                    "id": node_id,
                    "type": "server",
                    "data": {
                        "label": f"Server: {srv}",
                        "title": srv,
                        "service": srv_svc
                    },
                    "position": {"x": 50 + idx * 160, "y": 420}
                })
                
                # Connect Server to Service
                edges.append({
                    "id": f"edge-server-svc-{srv}",
                    "source": node_id,
                    "target": f"SERVICE-{srv_svc}",
                    "label": "hosts",
                    "style": {"stroke": "#A78BFA"}
                })

        # -------------------------------------------------------------
        # Correlate Events Cross-Domain (Edge Building)
        # -------------------------------------------------------------
        # Compare all event nodes for correlations
        event_nodes = list(node_map.keys())
        edge_id_counter = 1
        
        for i in range(len(event_nodes)):
            node_a = event_nodes[i]
            details_a = node_map[node_a]
            
            # Skip base Services & Employees (they are connected directly already)
            if details_a["type"] in ["service", "employee"]:
                continue
                
            for j in range(i + 1, len(event_nodes)):
                node_b = event_nodes[j]
                details_b = node_map[node_b]
                
                if details_b["type"] in ["service", "employee"]:
                    continue
                    
                correlations = []
                
                # 1. Temporal Correlation: within 15 minutes
                time_a = details_a["timestamp"]
                time_b = details_b["timestamp"]
                if time_a and time_b:
                    diff = abs((time_a - time_b).total_seconds()) / 60.0
                    if diff <= 15:
                        correlations.append(f"Temporal (~{int(diff)}m)")

                # 2. Service Co-occurrence
                if details_a["service"] == details_b["service"] and details_a["service"] is not None:
                    correlations.append("Shared Service")

                # 3. Employee overlaps
                if details_a["employee_id"] == details_b["employee_id"] and details_a["employee_id"] is not None:
                    correlations.append("Same Assignee/Author")

                # 4. Text/Keyword Similarities
                text_a = details_a.get("text", "").lower()
                text_b = details_b.get("text", "").lower()
                
                keywords = ["pool", "timeout", "auth", "connection", "login", "checkout", "transaction", "outage"]
                shared_keywords = []
                for kw in keywords:
                    if kw in text_a and kw in text_b:
                        shared_keywords.append(kw)
                
                if len(shared_keywords) > 0:
                    correlations.append(f"Keyword: {','.join(shared_keywords[:2])}")
                
                # If we have matches, create a correlation link
                if len(correlations) >= 2:
                    edges.append({
                        "id": f"edge-corr-{edge_id_counter}",
                        "source": node_a,
                        "target": node_b,
                        "label": " | ".join(correlations),
                        "animated": True,
                        "type": "smoothstep",
                        "style": {"stroke": "#EC4899", "strokeWidth": 2.5}
                    })
                    edge_id_counter += 1

        return {
            "nodes": nodes,
            "edges": edges
        }
