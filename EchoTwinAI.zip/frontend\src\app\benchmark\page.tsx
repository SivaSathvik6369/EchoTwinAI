"use client";

import { useState } from "react";
import { fetchBenchmark } from "@/lib/api";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function BenchmarkPage() {
  const [scale, setScale] = useState(5000);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any>(null);

  const runBenchmark = async () => {
    setLoading(true);
    try {
      const data = await fetchBenchmark(scale);
      setResults(data);
    } catch (err) {
      alert("Failed to execute benchmark.");
    } finally {
      setLoading(false);
    }
  };

  const chartData = results ? [
    {
      name: "Execution Latency (sec)",
      Pandas: parseFloat(results.pandas.execution_time_seconds.toFixed(4)),
      cuDF: parseFloat(results.cudf.execution_time_seconds.toFixed(4))
    },
    {
      name: "Throughput (K rows/sec)",
      Pandas: Math.round(results.pandas.rows_per_second / 1000),
      cuDF: Math.round(results.cudf.rows_per_second / 1000)
    }
  ] : [];

  return (
    <div className="flex flex-col gap-8 max-w-5xl mx-auto w-full">
      <div>
        <h1 className="text-3xl font-extrabold font-outfit text-white">GPU Acceleration Benchmark</h1>
        <p className="text-sm text-muted">Test local CPU-based Pandas against RAPIDS NVIDIA cuDF data engines.</p>
      </div>

      {/* Row count config */}
      <div className="glass p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h3 className="font-bold text-white font-outfit">Execution Scale</h3>
          <p className="text-xs text-muted">Select row dimensions for data cleaning, grouping, and aggregations.</p>
        </div>

        <div className="flex items-center gap-3">
          <select 
            value={scale} 
            onChange={(e) => setScale(parseInt(e.target.value))}
            className="bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-primary"
          >
            <option value={1000} className="bg-background">1,000 rows</option>
            <option value={5000} className="bg-background">5,000 rows</option>
            <option value={20000} className="bg-background">20,000 rows</option>
            <option value={50000} className="bg-background">50,000 rows</option>
            <option value={100000} className="bg-background">100,000 rows</option>
          </select>

          <button 
            onClick={runBenchmark}
            disabled={loading}
            className="py-2 px-6 bg-gradient-to-r from-primary to-secondary hover:opacity-90 disabled:opacity-50 text-white font-semibold text-sm rounded-xl transition-all"
          >
            {loading ? "Benchmarking..." : "🚀 Run Speed Test"}
          </button>
        </div>
      </div>

      {/* Benchmark results */}
      {results && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fadeIn">
          {/* Main Card */}
          <div className="glass p-6 rounded-2xl flex flex-col justify-between border-primary/20 bg-primary/5 lg:col-span-1 min-h-[220px]">
            <div>
              <span className="text-[10px] text-primary uppercase font-bold tracking-wider">GPU Accelerator Engine</span>
              <h3 className="text-4xl font-extrabold text-white font-outfit mt-2">{results.speedup_ratio}x</h3>
              <p className="text-sm font-semibold text-white mt-1">Speedup over standard Pandas</p>
            </div>
            
            <p className="text-[11px] text-muted border-t border-white/5 pt-3 leading-relaxed mt-4">
              {results.cudf.simulated 
                ? "💡 Running on CPU Emulation wrapper: Simulated NVIDIA RAPIDS performance profiles." 
                : "🔥 Running with active NVIDIA cuDF CUDA cores acceleration."}
            </p>
          </div>

          {/* Details side-by-side */}
          <div className="glass p-6 rounded-2xl flex flex-col gap-4 lg:col-span-2">
            <h3 className="font-bold text-white font-outfit border-b border-white/5 pb-2">Technical Breakdown ({results.rows_scale.toLocaleString()} rows)</h3>
            
            <div className="grid grid-cols-2 gap-4">
              {/* CPU Pandas */}
              <div className="bg-white/5 border border-white/5 p-4 rounded-xl space-y-3">
                <span className="text-[10px] text-muted uppercase font-bold tracking-wider">Standard Pandas (CPU)</span>
                <div>
                  <p className="text-xl font-bold text-white leading-none">{(results.pandas.execution_time_seconds * 1000).toFixed(1)} ms</p>
                  <span className="text-[10px] text-muted">Latency duration</span>
                </div>
                <div className="text-[10px] text-muted space-y-0.5 border-t border-white/5 pt-2">
                  <p>Rows/sec: {results.pandas.rows_per_second.toLocaleString()}</p>
                  <p>Memory: {(results.pandas.memory_bytes / 1024).toFixed(1)} KB</p>
                </div>
              </div>

              {/* GPU cuDF */}
              <div className="bg-primary/10 border border-primary/20 p-4 rounded-xl space-y-3">
                <span className="text-[10px] text-primary uppercase font-bold tracking-wider">NVIDIA cuDF (GPU)</span>
                <div>
                  <p className="text-xl font-bold text-white leading-none">{(results.cudf.execution_time_seconds * 1000).toFixed(1)} ms</p>
                  <span className="text-[10px] text-muted">Latency duration</span>
                </div>
                <div className="text-[10px] text-muted space-y-0.5 border-t border-white/5 pt-2">
                  <p>Rows/sec: {results.cudf.rows_per_second.toLocaleString()}</p>
                  <p>Memory: {(results.cudf.memory_bytes / 1024).toFixed(1)} KB</p>
                </div>
              </div>
            </div>
          </div>

          {/* Graphical representation */}
          <div className="glass p-6 rounded-2xl lg:col-span-3 flex flex-col gap-4">
            <h3 className="font-bold text-white font-outfit">Visual Performance Comparison</h3>
            <div className="h-64 w-full mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="name" stroke="#94A3B8" fontSize={11} />
                  <YAxis stroke="#94A3B8" fontSize={11} />
                  <Tooltip contentStyle={{ backgroundColor: "#0F111C", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "8px" }} />
                  <Bar dataKey="Pandas" fill="#94A3B8" radius={[4, 4, 0, 0]} name="Pandas (CPU)" />
                  <Bar dataKey="cuDF" fill="#8B5CF6" radius={[4, 4, 0, 0]} name="cuDF (GPU)" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
