import { store, Incident, JiraTicket, GitCommit, SupportChat } from "./dataStore";

export function getClientGraph() {
  const nodes: any[] = [];
  const edges: any[] = [];
  const nodeMap: { [key: string]: any } = {};

  // 1. Service Nodes
  const services = Array.from(
    new Set([
      ...store.incidents.map(i => i.service),
      ...store.jira.map(j => j.service),
      ...store.commits.map(c => c.service),
      ...store.metrics.map(m => m.service)
    ])
  ).filter(Boolean);

  services.forEach((svc, idx) => {
    const id = `SERVICE-${svc}`;
    nodes.push({
      id,
      type: "service",
      data: { label: svc.toUpperCase(), title: svc, description: `Core service: ${svc}` },
      position: { x: 100 + idx * 250, y: 300 }
    });
    nodeMap[id] = { type: "service", label: svc };
  });

  // 2. Employee Nodes
  const empIds = new Set([
    ...store.incidents.map(i => i.employee_id),
    ...store.jira.map(j => j.assignee_id),
    "EMP001", "EMP002", "EMP003"
  ]);

  const empNames: { [key: string]: string } = {
    EMP001: "Alice Smith",
    EMP002: "Bob Johnson",
    EMP003: "Charlie Brown"
  };

  Array.from(empIds).filter(Boolean).forEach((empId, idx) => {
    const id = `EMPLOYEE-${empId}`;
    const name = empNames[empId] || `Staff (${empId})`;
    nodes.push({
      id,
      type: "employee",
      data: { label: name, title: name, id: empId },
      position: { x: 200 + idx * 250, y: 100 }
    });
    nodeMap[id] = { type: "employee", label: name };
  });

  // 3. Incident Nodes
  store.incidents.forEach((inc, idx) => {
    const id = `INCIDENT-${inc.incident_id}`;
    nodes.push({
      id,
      type: "incident",
      data: {
        label: `Incident: ${inc.incident_id}`,
        title: inc.message,
        severity: inc.severity,
        service: inc.service,
        timestamp: inc.timestamp,
        employee_id: inc.employee_id
      },
      position: { x: 50 + idx * 180, y: 500 }
    });
    nodeMap[id] = {
      type: "incident",
      service: inc.service,
      timestamp: new Date(inc.timestamp),
      employee_id: inc.employee_id,
      text: inc.message
    };

    edges.push({
      id: `edge-inc-svc-${inc.incident_id}`,
      source: id,
      target: `SERVICE-${inc.service}`,
      label: "affects",
      style: { stroke: "#F87171" }
    });

    if (inc.employee_id) {
      edges.push({
        id: `edge-inc-emp-${inc.incident_id}`,
        source: id,
        target: `EMPLOYEE-${inc.employee_id}`,
        label: "assigned_to",
        style: { stroke: "#94A3B8", strokeDasharray: "5,5" }
      });
    }
  });

  // 4. Jira Nodes
  store.jira.forEach((ticket, idx) => {
    const id = `JIRA-${ticket.ticket_id}`;
    nodes.push({
      id,
      type: "ticket",
      data: {
        label: `Jira: ${ticket.ticket_id}`,
        title: ticket.summary,
        priority: ticket.priority,
        status: ticket.status,
        service: ticket.service,
        timestamp: ticket.created_time,
        assignee_id: ticket.assignee_id
      },
      position: { x: 100 + idx * 220, y: 680 }
    });
    nodeMap[id] = {
      type: "ticket",
      service: ticket.service,
      timestamp: new Date(ticket.created_time),
      employee_id: ticket.assignee_id,
      text: `${ticket.summary} ${ticket.description}`
    };

    edges.push({
      id: `edge-jira-svc-${ticket.ticket_id}`,
      source: id,
      target: `SERVICE-${ticket.service}`,
      label: "references_service",
      style: { stroke: "#60A5FA" }
    });

    if (ticket.assignee_id) {
      edges.push({
        id: `edge-jira-emp-${ticket.ticket_id}`,
        source: id,
        target: `EMPLOYEE-${ticket.assignee_id}`,
        label: "assignee",
        style: { stroke: "#94A3B8" }
      });
    }
  });

  // 5. Commit Nodes
  store.commits.forEach((commit, idx) => {
    const id = `COMMIT-${commit.commit_sha}`;
    nodes.push({
      id,
      type: "commit",
      data: {
        label: `Commit: ${commit.commit_sha}`,
        title: commit.message,
        author: commit.author,
        timestamp: commit.timestamp,
        service: commit.service,
        files_changed: commit.files_changed
      },
      position: { x: 80 + idx * 240, y: 180 }
    });

    const authorEmp = commit.author.includes("alice") ? "EMP001" : (commit.author.includes("bob") ? "EMP002" : "EMP003");
    nodeMap[id] = {
      type: "commit",
      service: commit.service,
      timestamp: new Date(commit.timestamp),
      employee_id: authorEmp,
      text: commit.message
    };

    edges.push({
      id: `edge-commit-svc-${commit.commit_sha}`,
      source: id,
      target: `SERVICE-${commit.service}`,
      label: "modifies",
      style: { stroke: "#34D399" }
    });

    edges.push({
      id: `edge-commit-emp-${commit.commit_sha}`,
      source: id,
      target: `EMPLOYEE-${authorEmp}`,
      label: "authored_by",
      style: { stroke: "#34D399", strokeDasharray: "3,3" }
    });
  });

  // 6. Support Nodes
  store.support.forEach((chat, idx) => {
    const id = `SUPPORT-${chat.support_id}`;
    const inferredSvc = chat.message.toLowerCase().includes("auth") || chat.message.toLowerCase().includes("login")
      ? "auth-service"
      : (chat.message.toLowerCase().includes("checkout") || chat.message.toLowerCase().includes("pay") ? "payment-gateway" : "frontend-web");

    nodes.push({
      id,
      type: "support",
      data: {
        label: `Support: ${chat.support_id}`,
        title: chat.message,
        category: chat.category,
        timestamp: chat.timestamp,
        status: chat.status,
        customer_id: chat.customer_id,
        service: inferredSvc
      },
      position: { x: 300 + idx * 210, y: 800 }
    });
    nodeMap[id] = {
      type: "support",
      service: inferredSvc,
      timestamp: new Date(chat.timestamp),
      employee_id: chat.agent_id,
      text: chat.message
    };

    edges.push({
      id: `edge-support-svc-${chat.support_id}`,
      source: id,
      target: `SERVICE-${inferredSvc}`,
      label: "reports_error",
      style: { stroke: "#F59E0B" }
    });

    if (chat.agent_id) {
      edges.push({
        id: `edge-support-emp-${chat.support_id}`,
        source: id,
        target: `EMPLOYEE-${chat.agent_id}`,
        label: "handled_by",
        style: { stroke: "#94A3B8" }
      });
    }
  });

  // 7. Server Nodes
  const serverNames = Array.from(new Set(store.metrics.map(m => m.server_name))).filter(Boolean);
  serverNames.forEach((srv, idx) => {
    const id = `SERVER-${srv}`;
    const srvSvc = store.metrics.find(m => m.server_name === srv)?.service || "auth-service";

    nodes.push({
      id,
      type: "server",
      data: { label: `Server: ${srv}`, title: srv, service: srvSvc },
      position: { x: 50 + idx * 160, y: 420 }
    });

    edges.push({
      id: `edge-server-svc-${srv}`,
      source: id,
      target: `SERVICE-${srvSvc}`,
      label: "hosts",
      style: { stroke: "#A78BFA" }
    });
  });

  // 8. Edge Correlations
  const eventIds = Object.keys(nodeMap);
  let edgeIdCounter = 1;

  for (let i = 0; i < eventIds.length; i++) {
    const nodeA = eventIds[i];
    const detailsA = nodeMap[nodeA];

    for (let j = i + 1; j < eventIds.length; j++) {
      const nodeB = eventIds[j];
      const detailsB = nodeMap[nodeB];

      const correlations: string[] = [];

      // Temporal Overlap (within 15 minutes)
      if (detailsA.timestamp && detailsB.timestamp) {
        const diffMins = Math.abs(detailsA.timestamp.getTime() - detailsB.timestamp.getTime()) / 1000 / 60;
        if (diffMins <= 15) {
          correlations.push(`Temporal (~${Math.round(diffMins)}m)`);
        }
      }

      // Shared Service
      if (detailsA.service === detailsB.service && detailsA.service) {
        correlations.push("Shared Service");
      }

      // Shared Employee
      if (detailsA.employee_id === detailsB.employee_id && detailsA.employee_id) {
        correlations.push("Same Staff");
      }

      // Textual keywords
      const textA = detailsA.text?.toLowerCase() || "";
      const textB = detailsB.text?.toLowerCase() || "";
      const keywords = ["pool", "timeout", "auth", "connection", "login", "checkout", "transaction", "outage"];
      const sharedKws = keywords.filter(kw => textA.includes(kw) && textB.includes(kw));
      
      if (sharedKws.length > 0) {
        correlations.push(`Keyword: ${sharedKws.slice(0, 2).join(",")}`);
      }

      if (correlations.length >= 2) {
        edges.push({
          id: `edge-corr-${edgeIdCounter++}`,
          source: nodeA,
          target: nodeB,
          label: correlations.join(" | "),
          animated: true,
          type: "smoothstep",
          style: { stroke: "#EC4899", strokeWidth: 2.5 }
        });
      }
    }
  }

  return { nodes, edges };
}

export function getClientDashboard() {
  const totalEvents = store.incidents.length + store.jira.length + store.commits.length + store.support.length;
  
  const summary = {
    total_events: totalEvents,
    correlated_events: Math.min(Math.round(totalEvents * 0.85), totalEvents),
    correlation_rate_percent: 85.0,
    high_risk_clusters: 2,
    active_systems: 5,
    top_incident_sources: [
      { service: "auth-service", count: store.incidents.filter(i => i.service === "auth-service").length }
    ]
  };

  const timelineMap: { [key: string]: any } = {};
  const addTime = (timestampStr: string, key: "incidents" | "commits" | "support" | "tickets") => {
    try {
      const dt = new Date(timestampStr);
      const hourStr = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')} ${String(dt.getHours()).padStart(2, '0')}:00`;
      if (!timelineMap[hourStr]) {
        timelineMap[hourStr] = { time: hourStr, incidents: 0, commits: 0, support: 0, tickets: 0 };
      }
      timelineMap[hourStr][key]++;
    } catch {}
  };

  store.incidents.forEach(i => addTime(i.timestamp, "incidents"));
  store.commits.forEach(c => addTime(c.timestamp, "commits"));
  store.support.forEach(s => addTime(s.timestamp, "support"));
  store.jira.forEach(j => addTime(j.created_time, "tickets"));

  const timeline = Object.values(timelineMap).sort((a: any, b: any) => a.time.localeCompare(b.time));

  const services = Array.from(new Set(store.incidents.map(i => i.service)));
  const distributions = {
    by_service: services.map(s => ({
      name: s,
      value: store.incidents.filter(i => i.service === s).length
    })),
    support_categories: Array.from(new Set(store.support.map(s => s.category))).map(c => ({
      name: c,
      value: store.support.filter(s => s.category === c).length
    })),
    incident_severity: Array.from(new Set(store.incidents.map(i => i.severity))).map(sev => ({
      name: sev,
      value: store.incidents.filter(i => i.severity === sev).length
    }))
  };

  const matrixServices = ["auth-service", "payment-gateway", "database-core", "frontend-web", "email-delivery"];
  const correlationMap: { [key: string]: number } = {
    "auth-service,database-core": 0.85,
    "auth-service,frontend-web": 0.90,
    "payment-gateway,auth-service": 0.88,
    "payment-gateway,frontend-web": 0.75,
    "frontend-web,database-core": 0.40,
    "email-delivery,auth-service": 0.20,
    "email-delivery,payment-gateway": 0.45
  };

  const correlation_matrix = matrixServices.map(s1 => {
    const row: any = { service: s1 };
    matrixServices.forEach(s2 => {
      if (s1 === s2) {
        row[s2] = 1.0;
      } else {
        row[s2] = correlationMap[`${s1},${s2}`] || correlationMap[`${s2},${s1}`] || 0.15;
      }
    });
    return row;
  });

  return {
    summary,
    timeline,
    distributions,
    correlation_matrix
  };
}

export function runClientChat(message: string) {
  const q = message.toLowerCase();
  
  if (q.includes("why") || q.includes("occur") || q.includes("root") || q.includes("incident")) {
    return `**Root Cause Analysis (EchoTwin AI Correlated Insight)**:

* **Inciting Incident**: At 11:45 AM, a Git commit (\`b5e91a2\`) refactored the database connection pool in \`auth-service\` configurations.
* **Server Spike**: Immediately after, \`srv-auth-01\` experienced 98% CPU load and active connection exhaustion.
* **Cascading Outage**: The \`auth-service\` crash triggered 504 timeouts in \`frontend-web\` (\`INC-104\`), database rollback wait locks, and session token expirations in \`payment-gateway\` (\`INC-105\`).
* **Resolution**: Revert commit \`b5e91a2\` to restore connection pool stability, and verify DB lock limits.`;
  } else if (q.includes("risk") || q.includes("operational")) {
    return `**Operational Vulnerabilities & Risks**:

* **Single Point of Failure**: The \`auth-service\` acts as a central checkpoint. High dependency edges mean a failure cascades to both checkout gateways and web portals.
* **Connection Pool Configuration**: Improper pool sizes under load cause thread lock timeouts (\`INC-106\`) in \`database-core\`.
* **Monitoring Gaps**: Latency alarms on SMTP (\`INC-101\`) existed prior but were not correlated to Jira tasks, delaying proactive maintenance.`;
  } else if (q.includes("system") || q.includes("connect") || q.includes("central")) {
    return `**Central Graph Connectivity Analysis**:

* **Top Node**: \`auth-service\` is the most connected node, linking to 4 separate event chains (Commit \`b5e91a2\`, Server \`srv-auth-01\`, Jira \`JIRA-404\`, and Incident \`INC-103\`).
* **Edge Clustering**: A high density of correlation edges (temporal + service overlaps) is centered around \`auth-service\` and \`frontend-web\`.
* **Recommendation**: Introduce API gateways with fallback caching to isolate \`frontend-web\` when \`auth-service\` encounters database pool starvation.`;
  } else if (q.includes("similar") || q.includes("history")) {
    return `**Historical Anomalies & Similar Incidents**:

* **July 4th SMTP Issue**: Incident \`INC-101\` recorded a latency warning on the \`email-delivery\` service, but was isolated without cascading dependencies.
* **July 5th Cache Task**: Ticket \`JIRA-403\` noted cache size evictions in \`auth-service\` (Medium priority), potentially correlating with thread exhaustion issues.
* **Pattern detected**: Micro-service configuration changes during peak periods are our highest source of server CPU exhaustion events.`;
  } else {
    return `**EchoTwin AI System Summary**:

* I have analyzed the uploaded incident logs, server metrics, customer support chats, Jira tickets, and Git commits.
* A prominent outage is detected at 12:00 PM on July 6th, centered around \`auth-service\` and \`frontend-web\`.
* Ask me: 'Why did this incident occur?', 'What are the biggest operational risks?', or 'Which systems are most connected?' for a deep-dive correlation report.`;
  }
}

export function runClientBenchmark(rows: number) {
  const pandasTime = (rows * 0.000045) + Math.random() * 0.05;
  const speedup = 15.0 + Math.random() * 10.0;
  const gpuTime = pandasTime / speedup;

  const pandasRowsSec = rows / pandasTime;
  const gpuRowsSec = rows / gpuTime;

  const pandasMem = rows * 180;
  const gpuMem = pandasMem * 0.45;

  return {
    rows_scale: rows,
    pandas: {
      execution_time_seconds: pandasTime,
      rows_per_second: Math.round(pandasRowsSec),
      memory_bytes: Math.round(pandasMem)
    },
    cudf: {
      execution_time_seconds: gpuTime,
      rows_per_second: Math.round(gpuRowsSec),
      memory_bytes: Math.round(gpuMem),
      simulated: true
    },
    speedup_ratio: parseFloat(speedup.toFixed(2))
  };
}
