import Link from "next/link";

export default function Home() {
  return (
    <div className="flex flex-col gap-12 max-w-5xl mx-auto pt-6 pb-12">
      {/* Hero Section */}
      <section className="text-center relative py-12 flex flex-col items-center gap-6">
        <div className="absolute top-0 w-72 h-72 bg-primary/20 rounded-full blur-3xl filter -z-10 animate-pulse" />
        
        <span className="px-3.5 py-1 rounded-full text-xs font-semibold tracking-wide bg-primary/10 border border-primary/20 text-primary uppercase font-outfit">
          Next-Gen SRE & Incident Intelligence
        </span>
        
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight font-outfit leading-tight">
          Resolve Cascading Outages with <br />
          <span className="text-gradient">EchoTwin AI</span>
        </h1>
        
        <p className="text-muted text-base md:text-lg max-w-2xl leading-relaxed">
          Correlate Millions of Disconnected Logs, Git Commits, Jira Tickets, and Support Chats into a single, unified Intelligence Graph. Accelerated by NVIDIA RAPIDS and explained by Google Gemini.
        </p>

        <div className="flex flex-wrap justify-center gap-4 mt-4">
          <Link 
            href="/upload" 
            className="px-6 py-3 rounded-xl font-medium bg-gradient-to-r from-primary to-secondary hover:from-primary-dark hover:to-secondary hover:shadow-[0_0_20px_rgba(139,92,246,0.4)] text-white shadow-lg transition-all"
            id="btn-get-started"
          >
            Upload Datasets &rarr;
          </Link>
          <Link 
            href="/dashboard" 
            className="px-6 py-3 rounded-xl font-medium bg-white/5 border border-white/10 hover:bg-white/10 text-white transition-all"
            id="btn-explore-dashboard"
          >
            Explore Dashboard
          </Link>
        </div>
      </section>

      {/* Feature Cards Grid */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass glass-hover p-6 rounded-2xl flex flex-col gap-4">
          <div className="text-3xl">⚡</div>
          <h3 className="font-bold text-lg text-white font-outfit">GPU-Accelerate Analytics</h3>
          <p className="text-sm text-muted leading-relaxed">
            Utilize cuDF & RAPIDS to preprocess files, normalize timestamps, and perform event joins up to 20x faster than standard CPU Pandas.
          </p>
        </div>

        <div className="glass glass-hover p-6 rounded-2xl flex flex-col gap-4">
          <div className="text-3xl">🕸️</div>
          <h3 className="font-bold text-lg text-white font-outfit">Multi-Domain Correlation</h3>
          <p className="text-sm text-muted leading-relaxed">
            Automatically construct relationships using temporal proximity, service dependencies, keyword similarity, and developer assignees.
          </p>
        </div>

        <div className="glass glass-hover p-6 rounded-2xl flex flex-col gap-4">
          <div className="text-3xl">🧠</div>
          <h3 className="font-bold text-lg text-white font-outfit">Gemini Explanation</h3>
          <p className="text-sm text-muted leading-relaxed">
            Query the chatbot directly on root causes, high-risk systems, and SRE resolution steps. Gemini translates graph edges into actionable ideas.
          </p>
        </div>
      </section>

      {/* Demo Scenario Timeline */}
      <section className="glass p-8 rounded-2xl flex flex-col gap-6">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-white font-outfit">Demo Outage Cascade Scenario</h2>
          <p className="text-xs text-muted mt-1">Pre-loaded in the platform and ready for analysis</p>
        </div>

        <div className="relative border-l border-white/10 pl-6 space-y-8 ml-2">
          {/* Step 1 */}
          <div className="relative">
            <div className="absolute -left-[30px] top-1.5 w-4.5 h-4.5 rounded-full bg-emerald-500 border-4 border-[#05060B]" />
            <span className="text-xs text-emerald-400 font-medium">11:45 AM &bull; Git Commit (`b5e91a2`)</span>
            <h4 className="text-sm font-semibold text-white mt-0.5">DB Pool Modification in `auth-service`</h4>
            <p className="text-xs text-muted mt-1">Alice Smith commits a configuration update changing database connection pools.</p>
          </div>
          {/* Step 2 */}
          <div className="relative">
            <div className="absolute -left-[30px] top-1.5 w-4.5 h-4.5 rounded-full bg-red-500 border-4 border-[#05060B] animate-ping" />
            <div className="absolute -left-[30px] top-1.5 w-4.5 h-4.5 rounded-full bg-red-500 border-4 border-[#05060B]" />
            <span className="text-xs text-red-400 font-medium">12:00 PM &bull; Server CPU & Incident Spike</span>
            <h4 className="text-sm font-semibold text-white mt-0.5">Auth Server Starvation</h4>
            <p className="text-xs text-muted mt-1">`srv-auth-01` spikes to 98% CPU. Incident `INC-103` reports connection pools exhausted.</p>
          </div>
          {/* Step 3 */}
          <div className="relative">
            <div className="absolute -left-[30px] top-1.5 w-4.5 h-4.5 rounded-full bg-yellow-500 border-4 border-[#05060B]" />
            <span className="text-xs text-yellow-400 font-medium">12:02 PM &bull; Gateway Cascades</span>
            <h4 className="text-sm font-semibold text-white mt-0.5">HTTP 504 Gateway Timeouts</h4>
            <p className="text-xs text-muted mt-1">`frontend-web` throws API timeouts. Payment transaction validations fail.</p>
          </div>
          {/* Step 4 */}
          <div className="relative">
            <div className="absolute -left-[30px] top-1.5 w-4.5 h-4.5 rounded-full bg-blue-500 border-4 border-[#05060B]" />
            <span className="text-xs text-blue-400 font-medium">12:04 PM &bull; Jira & Support Flood</span>
            <h4 className="text-sm font-semibold text-white mt-0.5">Support Tickets & Jira Blockers</h4>
            <p className="text-xs text-muted mt-1">Customers file complaints about login timeouts. Highest priority ticket `JIRA-404` filed.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
