"use client";

import { useState } from "react";
import { API_BASE_URL } from "../../config";

export default function UploadPage() {
  const [activeDatasets, setActiveDatasets] = useState({
    incidents: { name: "default_incident_logs.csv", rows: 6, status: "Active" },
    jira: { name: "default_jira_tickets.csv", rows: 4, status: "Active" },
    commits: { name: "default_git_commits.csv", rows: 4, status: "Active" },
    metrics: { name: "default_server_metrics.csv", rows: 220, status: "Active" },
    support: { name: "default_customer_support.json", rows: 4, status: "Active" }
  });

  const [loading, setLoading] = useState(false);
  const [processResult, setProcessResult] = useState<any>(null);
  const [selectedType, setSelectedType] = useState("incidents");
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  const handleUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setUploadStatus("Uploading...");
    const formData = new FormData(e.currentTarget);
    
    try {
      const response = await fetch(`${API_BASE_URL}/upload`, {
        method: "POST",
        body: formData,
      });
      const data = await response.json();
      if (response.ok && data.success) {
        setUploadStatus("Upload Successful!");
        // Update state
        const fileInput = e.currentTarget.elements.namedItem("file") as HTMLInputElement;
        const uploadedName = fileInput.files?.[0]?.name || "uploaded_file";
        setActiveDatasets(prev => ({
          ...prev,
          [selectedType]: {
            name: uploadedName,
            rows: data.rows_count,
            status: "Active"
          }
        }));
      } else {
        setUploadStatus(`Error: ${data.detail || "Failed to upload"}`);
      }
    } catch (err: any) {
      setUploadStatus(`Error connecting to server: ${err.message}`);
    }
  };

  const triggerPreprocessing = async () => {
    setLoading(true);
    setProcessResult(null);
    try {
      const response = await fetch(`${API_BASE_URL}/process`, {
        method: "POST",
      });
      const data = await response.json();
      if (response.ok) {
        setProcessResult(data);
      } else {
        alert("Pipeline processing error");
      }
    } catch (err: any) {
      alert(`Error reaching pipeline server: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-8 max-w-5xl mx-auto w-full">
      <div>
        <h1 className="text-3xl font-extrabold font-outfit text-white">Upload Center</h1>
        <p className="text-sm text-muted">Ingest organizational events and run GPU preprocessing tasks.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Upload Panel */}
        <div className="glass p-6 rounded-2xl flex flex-col gap-4 lg:col-span-1">
          <h2 className="text-lg font-bold text-white font-outfit border-b border-white/5 pb-2">Upload Dataset</h2>
          
          <form onSubmit={handleUpload} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-muted">Dataset Category</label>
              <select 
                name="dataset_type" 
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-primary"
              >
                <option value="incidents" className="bg-background">Incident Logs (CSV)</option>
                <option value="jira" className="bg-background">Jira Tickets (CSV)</option>
                <option value="commits" className="bg-background">Git Commits (CSV)</option>
                <option value="metrics" className="bg-background">Server Metrics (CSV)</option>
                <option value="support" className="bg-background">Customer Support (JSON)</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-muted">File Select</label>
              <input 
                type="file" 
                name="file" 
                required
                accept=".csv,.json,.xlsx,.xls"
                className="bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm text-white file:bg-primary file:border-0 file:rounded-lg file:px-2.5 file:py-1 file:text-xs file:font-semibold file:text-white file:cursor-pointer file:mr-2 hover:bg-white/10 cursor-pointer"
              />
            </div>

            <button 
              type="submit"
              className="mt-2 py-2 px-4 bg-primary hover:bg-primary-dark text-white text-sm font-semibold rounded-xl transition-all"
            >
              Upload
            </button>

            {uploadStatus && (
              <span className={`text-xs text-center font-medium ${uploadStatus.includes("Error") ? "text-red-400" : "text-emerald-400"}`}>
                {uploadStatus}
              </span>
            )}
          </form>
        </div>

        {/* Ingestion Pipeline Summary */}
        <div className="glass p-6 rounded-2xl flex flex-col gap-6 lg:col-span-2">
          <div className="flex justify-between items-center border-b border-white/5 pb-2">
            <h2 className="text-lg font-bold text-white font-outfit">Active Platform Datasets</h2>
            <button 
              onClick={triggerPreprocessing}
              disabled={loading}
              className="py-1.5 px-4 bg-gradient-to-r from-primary to-secondary hover:opacity-90 disabled:opacity-50 text-white text-xs font-semibold rounded-xl transition-all"
            >
              {loading ? "Processing..." : "⚡ Run GPU Pipeline"}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(activeDatasets).map(([key, info]) => (
              <div key={key} className="bg-white/5 border border-white/5 p-4 rounded-xl flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-muted uppercase tracking-wide">{key}</h4>
                  <p className="text-sm font-medium text-white truncate max-w-[200px] mt-0.5">{info.name}</p>
                  <span className="text-[11px] text-muted">{info.rows} records detected</span>
                </div>
                <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-semibold uppercase rounded-full">
                  {info.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* GPU Preprocessing Results */}
      {processResult && (
        <div className="glass p-6 rounded-2xl flex flex-col gap-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-white font-outfit">GPU Pipeline Execution Report</h2>
            <p className="text-xs text-muted">Completed in {processResult.total_execution_time_seconds.toFixed(4)}s. Status: {processResult.is_gpu_accelerated ? "NVIDIA cuDF Hardware Acceleration Active" : "CPU Fallback Mode Active"}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {Object.entries(processResult.stages).map(([stageName, metrics]: any) => (
              <div key={stageName} className="bg-white/5 border border-white/5 p-3 rounded-xl flex flex-col gap-1.5">
                <h4 className="text-[10px] font-bold text-muted uppercase tracking-wider truncate">{stageName}</h4>
                <div>
                  <p className="text-lg font-bold text-white leading-none">{(metrics.execution_time_seconds * 1000).toFixed(1)}<span className="text-xs font-normal text-muted"> ms</span></p>
                  <span className="text-[10px] text-muted">Time taken</span>
                </div>
                <div className="border-t border-white/5 pt-1 text-[10px] text-muted space-y-0.5">
                  <p>Rows: {metrics.rows_processed}</p>
                  <p>Mem: {(metrics.memory_bytes / 1024).toFixed(1)} KB</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
