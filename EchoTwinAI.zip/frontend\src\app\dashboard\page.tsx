"use client";

import { useEffect, useState } from "react";
import { fetchDashboard } from "@/lib/api";
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function DashboardPage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [mounted, setMounted] = useState(false);
  const [showLooker, setShowLooker] = useState(false);

  useEffect(() => {
    setMounted(true);
    const getDashboard = async () => {
      try {
        const json = await fetchDashboard();
        setData(json);
      } catch (err) {
        console.error("Error loading dashboard data", err);
      } finally {
        setLoading(false);
      }
    };
    getDashboard();
  }, []);

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p>Compiling database analytics...</p>
        </div>
      </div>
    );
  }

  const { summary, timeline, distributions, correlation_matrix, looker_dataset } = data || {};
  
  // Colors for charts
  const PIE_COLORS = ["#EF4444", "#F59E0B", "#3B82F6", "#10B981"];

  return (
    <div className="flex flex-col gap-8 max-w-5xl mx-auto w-full">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold font-outfit text-white">Analytics Dashboard</h1>
          <p className="text-sm text-muted">System analytics and correlation metrics from the GPU pipeline.</p>
        </div>
        
        <button 
          onClick={() => setShowLooker(!showLooker)}
          className="py-2 px-4 bg-white/5 border border-white/10 hover:bg-white/10 text-white text-xs font-semibold rounded-xl transition-all"
        >
          {showLooker ? "📊 View Charts" : "🔍 Looker Config"}
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="glass p-5 rounded-2xl flex flex-col gap-1">
          <span className="text-xs text-muted uppercase font-bold tracking-wider">Total Events</span>
          <h3 className="text-3xl font-extrabold text-white font-outfit mt-1">{summary?.total_events}</h3>
          <span className="text-[10px] text-muted">Ingested logs & events</span>
        </div>
        <div className="glass p-5 rounded-2xl flex flex-col gap-1">
          <span className="text-xs text-muted uppercase font-bold tracking-wider">Correlated</span>
          <h3 className="text-3xl font-extrabold text-white font-outfit mt-1">{summary?.correlated_events}</h3>
          <span className="text-[10px] text-primary font-semibold">{summary?.correlation_rate_percent}% correlation rate</span>
        </div>
        <div className="glass p-5 rounded-2xl flex flex-col gap-1">
          <span className="text-xs text-muted uppercase font-bold tracking-wider">Risk Clusters</span>
          <h3 className="text-3xl font-extrabold text-red-400 font-outfit mt-1">{summary?.high_risk_clusters}</h3>
          <span className="text-[10px] text-red-400/80 font-semibold">Cascades identified</span>
        </div>
        <div className="glass p-5 rounded-2xl flex flex-col gap-1">
          <span className="text-xs text-muted uppercase font-bold tracking-wider">Active Services</span>
          <h3 className="text-3xl font-extrabold text-white font-outfit mt-1">{summary?.active_systems}</h3>
          <span className="text-[10px] text-muted">Micro-components running</span>
        </div>
        <div className="glass p-5 rounded-2xl flex flex-col gap-1">
          <span className="text-xs text-muted uppercase font-bold tracking-wider">Top Source</span>
          <h3 className="text-lg font-bold text-white truncate font-outfit mt-2">{summary?.top_incident_sources[0]?.service || "auth-service"}</h3>
          <span className="text-[10px] text-muted">{summary?.top_incident_sources[0]?.count || 3} incidents logs</span>
        </div>
      </div>

      {showLooker ? (
        /* Looker Metadata Mode */
        <div className="glass p-6 rounded-2xl flex flex-col gap-4 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-white font-outfit">Looker-Ready Datasets Config</h2>
            <p className="text-xs text-muted">LookML schema configurations to connect BigQuery datasets to Looker dashboards.</p>
          </div>
          <pre className="bg-[#0A0B10] p-4 rounded-xl text-xs text-emerald-400 overflow-x-auto border border-white/5 font-mono max-h-[400px]">
            {`# LookML View Definition for EchoTwin AI
view: echotwin_correlated_events {
  sql_table_name: \`\${state.project_id}.echotwin_dataset.incidents\` ;;

  dimension: incident_id {
    primary_key: yes
    type: string
    sql: \${TABLE}.incident_id ;;
  }

  dimension_group: event_timestamp {
    type: time
    timeframes: [raw, time, date, week, month]
    sql: \${TABLE}.timestamp ;;
  }

  dimension: service_name {
    type: string
    sql: \${TABLE}.service ;;
  }

  dimension: severity_level {
    type: string
    sql: \${TABLE}.severity ;;
  }

  measure: total_incidents {
    type: count
    drill_fields: [incident_id, service_name, severity_level]
  }

  measure: high_severity_incidents {
    type: count
    filters: [severity_level: "CRITICAL, ERROR"]
  }
}`}
          </pre>
        </div>
      ) : (
        /* Standard Charts Mode */
        <div className="flex flex-col gap-8">
          {/* Main Timeline */}
          {mounted && (
            <div className="glass p-6 rounded-2xl flex flex-col gap-4">
              <h2 className="text-lg font-bold text-white font-outfit">Incident & Deployments Timeline</h2>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={timeline}>
                    <defs>
                      <linearGradient id="colorIncidents" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#EF4444" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorCommits" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10B981" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="time" stroke="#94A3B8" fontSize={11} />
                    <YAxis stroke="#94A3B8" fontSize={11} />
                    <Tooltip contentStyle={{ backgroundColor: "#0F111C", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "8px" }} />
                    <Area type="monotone" dataKey="incidents" stroke="#EF4444" fillOpacity={1} fill="url(#colorIncidents)" name="Incidents" />
                    <Area type="monotone" dataKey="commits" stroke="#10B981" fillOpacity={1} fill="url(#colorCommits)" name="Commits" />
                    <Area type="monotone" dataKey="support" stroke="#F59E0B" fillOpacity={0} name="Support Chats" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Correlation Matrix Heatmap */}
            <div className="glass p-6 rounded-2xl flex flex-col gap-4">
              <h2 className="text-lg font-bold text-white font-outfit">Service Correlation Matrix</h2>
              <div className="flex flex-col gap-1.5 mt-2">
                {/* Header row */}
                <div className="grid grid-cols-6 text-[10px] font-bold text-muted uppercase tracking-wider text-center">
                  <div></div>
                  <div className="truncate">auth</div>
                  <div className="truncate">pay</div>
                  <div className="truncate">db</div>
                  <div className="truncate">web</div>
                  <div className="truncate">mail</div>
                </div>
                {/* Rows */}
                {correlation_matrix?.map((row: any, idx: number) => {
                  const cells = ["auth-service", "payment-gateway", "database-core", "frontend-web", "email-delivery"];
                  return (
                    <div key={idx} className="grid grid-cols-6 items-center text-xs text-center">
                      <div className="text-[10px] font-semibold text-muted text-left truncate pr-1">{row.service.replace("-service", "").replace("-core", "").replace("-web", "").replace("-delivery", "")}</div>
                      {cells.map((cell, cIdx) => {
                        const val = row[cell];
                        let bg = "bg-white/5 text-muted";
                        if (val >= 0.8) bg = "bg-red-500/20 border border-red-500/35 text-red-400 font-bold";
                        else if (val >= 0.5) bg = "bg-amber-500/20 border border-amber-500/30 text-amber-400 font-semibold";
                        else if (val >= 0.3) bg = "bg-blue-500/10 border border-blue-500/20 text-blue-400";
                        return (
                          <div key={cIdx} className={`py-2 mx-0.5 rounded-lg flex items-center justify-center ${bg}`}>
                            {val.toFixed(2)}
                          </div>
                        );
                      })}
                    </div>
                  );
                })}
              </div>
              <span className="text-[10px] text-muted mt-2">&bull; Values range from 0.00 (independent) to 1.00 (direct relationship). High correlation flags SRE alerts.</span>
            </div>

            {/* Severity and Categorical breakdown */}
            {mounted && (
              <div className="glass p-6 rounded-2xl flex flex-col gap-4">
                <h2 className="text-lg font-bold text-white font-outfit">Incident Severity Distribution</h2>
                <div className="h-48 w-full flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={distributions?.incident_severity}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={70}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {distributions?.incident_severity.map((entry: any, index: number) => (
                          <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: "#0F111C", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "8px" }} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex flex-col gap-2 shrink-0">
                    {distributions?.incident_severity.map((item: any, index: number) => (
                      <div key={item.name} className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full" style={{ backgroundColor: PIE_COLORS[index % PIE_COLORS.length] }} />
                        <span className="text-xs text-white font-medium">{item.name} ({item.value})</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
