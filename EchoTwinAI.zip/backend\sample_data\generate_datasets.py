import os
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_all_datasets(output_dir="."):
    os.makedirs(output_dir, exist_ok=True)
    
    # Base configuration
    base_time = datetime(2026, 7, 6, 12, 0, 0)
    services = ["auth-service", "payment-gateway", "database-core", "frontend-web", "email-delivery"]
    employees = [
        {"id": "EMP001", "name": "Alice Smith", "email": "alice@company.com"},
        {"id": "EMP002", "name": "Bob Johnson", "email": "bob@company.com"},
        {"id": "EMP003", "name": "Charlie Brown", "email": "charlie@company.com"}
    ]
    servers = {
        "auth-service": ["srv-auth-01", "srv-auth-02"],
        "payment-gateway": ["srv-pay-01", "srv-pay-02"],
        "database-core": ["srv-db-01", "srv-db-02"],
        "frontend-web": ["srv-web-01", "srv-web-02", "srv-web-03"],
        "email-delivery": ["srv-mail-01"]
    }
    customers = ["CUST-901", "CUST-902", "CUST-903", "CUST-904", "CUST-905"]
    
    # -------------------------------------------------------------
    # 1. Server Metrics (CSV)
    # -------------------------------------------------------------
    metrics_data = []
    # Normal metrics spanning 24 hours (every 1 hour)
    for h in range(-24, 12):
        t = base_time + timedelta(hours=h)
        for srv_list in servers.values():
            for srv in srv_list:
                cpu = np.random.uniform(10, 45)
                mem = np.random.uniform(30, 60)
                conn = int(np.random.uniform(50, 200))
                metrics_data.append({
                    "timestamp": t.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "server_name": srv,
                    "cpu_utilization": round(cpu, 2),
                    "memory_utilization": round(mem, 2),
                    "active_connections": conn,
                    "service": [k for k, v in servers.items() if srv in v][0]
                })
    
    # Incident spike metrics (around 12:00:00)
    # Spike in auth-service server-01 cpu and connections drop
    for m in range(-30, 60, 5):
        t = base_time + timedelta(minutes=m)
        # Auth service Server-01 spikes
        metrics_data.append({
            "timestamp": t.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "server_name": "srv-auth-01",
            "cpu_utilization": round(98.5 + np.random.uniform(-2, 1), 2) if m >= 0 else round(np.random.uniform(20, 40), 2),
            "memory_utilization": round(92.1 + np.random.uniform(-1, 1.5), 2) if m >= 0 else round(np.random.uniform(40, 50), 2),
            "active_connections": int(np.random.uniform(5, 20)) if m >= 0 else int(np.random.uniform(120, 180)),
            "service": "auth-service"
        })
        # Database server core-01 metrics connection count spikes due to locks
        metrics_data.append({
            "timestamp": t.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "server_name": "srv-db-01",
            "cpu_utilization": round(85.0 + np.random.uniform(-5, 5), 2) if m >= 5 else round(np.random.uniform(15, 30), 2),
            "memory_utilization": round(78.0 + np.random.uniform(-2, 3), 2) if m >= 5 else round(np.random.uniform(50, 60), 2),
            "active_connections": int(np.random.uniform(400, 550)) if m >= 5 else int(np.random.uniform(80, 120)),
            "service": "database-core"
        })
        
    df_metrics = pd.DataFrame(metrics_data)
    df_metrics.drop_duplicates(subset=["timestamp", "server_name"], inplace=True)
    df_metrics.to_csv(os.path.join(output_dir, "server_metrics.csv"), index=False)
    
    # -------------------------------------------------------------
    # 2. Git Commits (CSV)
    # -------------------------------------------------------------
    commits_data = [
        # Some random old commits
        {"commit_sha": "d3a5e12", "timestamp": (base_time - timedelta(days=2)).strftime("%Y-%m-%dT%H:%M:%SZ"), "author": "bob@company.com", "message": "Updated payment form UI validations", "files_changed": "frontend/src/payment.tsx", "service": "frontend-web"},
        {"commit_sha": "f8a12e9", "timestamp": (base_time - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ"), "author": "charlie@company.com", "message": "Added indices on transactions table", "files_changed": "db/migrations/032_idx.sql", "service": "database-core"},
        {"commit_sha": "9a38fcd", "timestamp": (base_time - timedelta(hours=3)).strftime("%Y-%m-%dT%H:%M:%SZ"), "author": "alice@company.com", "message": "Optimized token parsing cache in gateway", "files_changed": "auth/cache.py", "service": "auth-service"},
        # THE INCITING COMMIT (15 mins before outage)
        {"commit_sha": "b5e91a2", "timestamp": (base_time - timedelta(minutes=15)).strftime("%Y-%m-%dT%H:%M:%SZ"), "author": "alice@company.com", "message": "Refactored DB connection pool timeout in auth-service configuration", "files_changed": "auth/config.py, auth/db.py", "service": "auth-service"}
    ]
    pd.DataFrame(commits_data).to_csv(os.path.join(output_dir, "git_commits.csv"), index=False)
    
    # -------------------------------------------------------------
    # 3. Incident Logs (CSV)
    # -------------------------------------------------------------
    incidents = [
        {"incident_id": "INC-101", "timestamp": (base_time - timedelta(hours=10)).strftime("%Y-%m-%dT%H:%M:%SZ"), "service": "email-delivery", "severity": "WARNING", "message": "SMTP connection slow latency check failed", "employee_id": "EMP002"},
        {"incident_id": "INC-102", "timestamp": (base_time - timedelta(hours=5)).strftime("%Y-%m-%dT%H:%M:%SZ"), "service": "frontend-web", "severity": "INFO", "message": "Static assets bundle deployed", "employee_id": "EMP003"},
        # Outage cascading events
        {"incident_id": "INC-103", "timestamp": base_time.strftime("%Y-%m-%dT%H:%M:%SZ"), "service": "auth-service", "severity": "CRITICAL", "message": "Database connection pool exhausted. DB connection timeout in auth-service.", "employee_id": "EMP001"},
        {"incident_id": "INC-104", "timestamp": (base_time + timedelta(minutes=2)).strftime("%Y-%m-%dT%H:%M:%SZ"), "service": "frontend-web", "severity": "ERROR", "message": "HTTP 504 Gateway Timeout requesting auth token validation from auth-service", "employee_id": "EMP003"},
        {"incident_id": "INC-105", "timestamp": (base_time + timedelta(minutes=5)).strftime("%Y-%m-%dT%H:%M:%SZ"), "service": "payment-gateway", "severity": "ERROR", "message": "Transaction failed: cannot authenticate payment payload session token expired", "employee_id": "EMP002"},
        {"incident_id": "INC-106", "timestamp": (base_time + timedelta(minutes=8)).strftime("%Y-%m-%dT%H:%M:%SZ"), "service": "database-core", "severity": "WARNING", "message": "Lock wait timeout exceeded in database-core backend transaction rollback", "employee_id": "EMP001"}
    ]
    pd.DataFrame(incidents).to_csv(os.path.join(output_dir, "incident_logs.csv"), index=False)
    
    # -------------------------------------------------------------
    # 4. Jira Tickets (CSV)
    # -------------------------------------------------------------
    jira_tickets = [
        {"ticket_id": "JIRA-402", "created_time": (base_time - timedelta(days=3)).strftime("%Y-%m-%dT%H:%M:%SZ"), "updated_time": (base_time - timedelta(days=2)).strftime("%Y-%m-%dT%H:%M:%SZ"), "summary": "Styling issues on checkout screen", "description": "Border alignment on mobile check-out form is misaligned", "assignee_id": "EMP003", "service": "frontend-web", "status": "Done", "priority": "Low"},
        {"ticket_id": "JIRA-403", "created_time": (base_time - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ"), "updated_time": (base_time - timedelta(hours=4)).strftime("%Y-%m-%dT%H:%M:%SZ"), "summary": "Fix cache evictions", "description": "Cache size exceeds limits occasionally, need eviction strategy", "assignee_id": "EMP001", "service": "auth-service", "status": "In Progress", "priority": "Medium"},
        # Outage tickets
        {"ticket_id": "JIRA-404", "created_time": (base_time + timedelta(minutes=10)).strftime("%Y-%m-%dT%H:%M:%SZ"), "updated_time": (base_time + timedelta(minutes=20)).strftime("%Y-%m-%dT%H:%M:%SZ"), "summary": "Critical: Auth service connection pool exhaustion crashes frontend gateway", "description": "Users are locked out and HTTP 504 timeouts are flooding frontend logs. Investigating connection pool refactoring commit.", "assignee_id": "EMP001", "service": "auth-service", "status": "Open", "priority": "Highest"},
        {"ticket_id": "JIRA-405", "created_time": (base_time + timedelta(minutes=18)).strftime("%Y-%m-%dT%H:%M:%SZ"), "updated_time": (base_time + timedelta(minutes=18)).strftime("%Y-%m-%dT%H:%M:%SZ"), "summary": "Payment checkout service failing for all users", "description": "Unable to process transactions since 12:00 PM. High priority failure reported from customer support.", "assignee_id": "EMP002", "service": "payment-gateway", "status": "Open", "priority": "Highest"}
    ]
    pd.DataFrame(jira_tickets).to_csv(os.path.join(output_dir, "jira_tickets.csv"), index=False)
    
    # -------------------------------------------------------------
    # 5. Customer Support (JSON)
    # -------------------------------------------------------------
    support_chats = [
        # Normal chats
        {
            "support_id": "SUP-801",
            "timestamp": (base_time - timedelta(hours=4)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "customer_id": "CUST-903",
            "category": "Billing",
            "message": "Where can I download my invoice for last month?",
            "status": "Resolved",
            "agent_id": "EMP002"
        },
        # Outage chats
        {
            "support_id": "SUP-802",
            "timestamp": (base_time + timedelta(minutes=4)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "customer_id": "CUST-901",
            "category": "Authentication Failure",
            "message": "I am trying to log into the dashboard but it gives me a gateway timeout error. Please fix!",
            "status": "Open",
            "agent_id": "EMP003"
        },
        {
            "support_id": "SUP-803",
            "timestamp": (base_time + timedelta(minutes=7)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "customer_id": "CUST-902",
            "category": "Checkout Loop",
            "message": "Whenever I click buy, the loading spinner spins forever, then says token expired. I tried 3 times.",
            "status": "Open",
            "agent_id": "EMP002"
        },
        {
            "support_id": "SUP-804",
            "timestamp": (base_time + timedelta(minutes=12)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "customer_id": "CUST-904",
            "category": "Login Outage",
            "message": "The entire app is down. Getting blank screen and auth connection errors. Are you experiencing an outage?",
            "status": "Open",
            "agent_id": "EMP003"
        }
    ]
    with open(os.path.join(output_dir, "customer_support.json"), "w") as f:
        json.dump(support_chats, f, indent=4)
        
    print("All datasets generated successfully!")

if __name__ == "__main__":
    generate_all_datasets(".")
