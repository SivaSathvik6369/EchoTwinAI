"use client";

import { useEffect, useState, useMemo } from "react";
import { fetchGraph } from "@/lib/api";
import { 
  ReactFlow, 
  Background, 
  Controls, 
  MiniMap, 
  useNodesState, 
  useEdgesState,
  Handle,
  Position
} from "@xyflow/react";

// -------------------------------------------------------------
// Premium Custom Node Designs
// -------------------------------------------------------------
const ServiceNode = ({ data }: any) => (
  <div className="glass px-4 py-3 rounded-xl border border-primary/50 shadow-[0_0_12px_rgba(139,92,246,0.15)] text-center min-w-[160px] bg-primary/10">
    <div className="text-[9px] font-bold text-primary uppercase tracking-wider">⚙️ Core Service</div>
    <div className="text-sm font-extrabold text-white mt-0.5 font-outfit">{data.label}</div>
    <Handle type="source" position={Position.Bottom} className="!bg-primary" />
    <Handle type="target" position={Position.Top} className="!bg-primary" />
  </div>
);

const IncidentNode = ({ data }: any) => (
  <div className="glass px-4 py-2.5 rounded-xl border border-red-500/50 shadow-[0_0_15px_rgba(239,68,68,0.2)] text-left min-w-[150px] bg-red-500/5">
    <div className="text-[9px] font-bold text-red-400 uppercase tracking-wider flex items-center gap-1">
      <span className="animate-ping w-1.5 h-1.5 rounded-full bg-red-500 inline-block" />
      🚨 Critical Incident
    </div>
    <div className="text-xs font-bold text-white mt-1 truncate max-w-[130px]">{data.label}</div>
    <div className="text-[10px] text-muted truncate max-w-[130px] mt-0.5">{data.title}</div>
    <Handle type="source" position={Position.Bottom} className="!bg-red-400" />
    <Handle type="target" position={Position.Top} className="!bg-red-400" />
  </div>
);

const CommitNode = ({ data }: any) => (
  <div className="glass px-4 py-2.5 rounded-xl border border-accent/50 shadow-[0_0_12px_rgba(16,185,129,0.15)] text-left min-w-[150px] bg-accent/5">
    <div className="text-[9px] font-bold text-accent uppercase tracking-wider">🌿 Git Commit</div>
    <div className="text-xs font-bold text-white mt-1 truncate max-w-[130px]">{data.label}</div>
    <div className="text-[10px] text-muted truncate max-w-[130px] mt-0.5">{data.title}</div>
    <Handle type="source" position={Position.Bottom} className="!bg-accent" />
    <Handle type="target" position={Position.Top} className="!bg-accent" />
  </div>
);

const TicketNode = ({ data }: any) => (
  <div className="glass px-4 py-2.5 rounded-xl border border-blue-500/50 shadow-[0_0_12px_rgba(59,130,246,0.15)] text-left min-w-[150px] bg-blue-500/5">
    <div className="text-[9px] font-bold text-blue-400 uppercase tracking-wider">🎫 Jira Ticket</div>
    <div className="text-xs font-bold text-white mt-1 truncate max-w-[130px]">{data.label}</div>
    <div className="text-[10px] text-muted truncate max-w-[130px] mt-0.5">{data.title}</div>
    <Handle type="source" position={Position.Bottom} className="!bg-blue-400" />
    <Handle type="target" position={Position.Top} className="!bg-blue-400" />
  </div>
);

const SupportNode = ({ data }: any) => (
  <div className="glass px-4 py-2.5 rounded-xl border border-secondary/50 shadow-[0_0_12px_rgba(236,72,153,0.15)] text-left min-w-[150px] bg-secondary/5">
    <div className="text-[9px] font-bold text-secondary uppercase tracking-wider">💬 Customer support</div>
    <div className="text-xs font-bold text-white mt-1 truncate max-w-[130px]">{data.label}</div>
    <div className="text-[10px] text-muted truncate max-w-[130px] mt-0.5">{data.title}</div>
    <Handle type="source" position={Position.Bottom} className="!bg-secondary" />
    <Handle type="target" position={Position.Top} className="!bg-secondary" />
  </div>
);

const ServerNode = ({ data }: any) => (
  <div className="glass px-4 py-2.5 rounded-xl border border-purple-400/40 text-left min-w-[140px] bg-purple-500/5">
    <div className="text-[9px] font-bold text-purple-300 uppercase tracking-wider">🖥️ Server Hardware</div>
    <div className="text-xs font-bold text-white mt-0.5 truncate max-w-[125px]">{data.label}</div>
    <Handle type="source" position={Position.Bottom} className="!bg-purple-300" />
    <Handle type="target" position={Position.Top} className="!bg-purple-300" />
  </div>
);

const EmployeeNode = ({ data }: any) => (
  <div className="glass px-4 py-2 rounded-full border border-white/20 text-center min-w-[130px] bg-white/5">
    <div className="text-[10px] font-semibold text-white truncate">{data.label}</div>
    <Handle type="source" position={Position.Bottom} className="!bg-slate-400" />
    <Handle type="target" position={Position.Top} className="!bg-slate-400" />
  </div>
);

export default function GraphPage() {
  const [nodes, setNodes, onNodesChange] = useNodesState<any>([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState<any>([]);
  
  // Unfiltered nodes and edges cache
  const [rawNodes, setRawNodes] = useState<any[]>([]);
  const [rawEdges, setRawEdges] = useState<any[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [selectedNode, setSelectedNode] = useState<any>(null);
  
  // Filters state
  const [filters, setFilters] = useState({
    service: true,
    server: true,
    incident: true,
    ticket: true,
    commit: true,
    support: true,
    employee: true
  });

  const nodeTypes = useMemo(() => ({
    service: ServiceNode,
    incident: IncidentNode,
    commit: CommitNode,
    ticket: TicketNode,
    support: SupportNode,
    server: ServerNode,
    employee: EmployeeNode
  }), []);

  useEffect(() => {
    const getGraph = async () => {
      try {
        const data = await fetchGraph();
        setRawNodes(data.nodes || []);
        setRawEdges(data.edges || []);
        
        // Initial setup
        setNodes(data.nodes || []);
        setEdges(data.edges || []);
      } catch (err) {
        console.error("Error loading correlation graph", err);
      } finally {
        setLoading(false);
      }
    };
    getGraph();
  }, [setNodes, setEdges]);

  // Apply filters on node types
  useEffect(() => {
    if (loading) return;

    // Filter nodes
    const filteredNodes = rawNodes.filter((node: any) => {
      const type = node.type;
      return filters[type as keyof typeof filters];
    });

    // Build map of active node IDs
    const activeNodeIds = new Set(filteredNodes.map((n: any) => n.id));

    // Filter edges (only keep edges where both source and target exist)
    const filteredEdges = rawEdges.filter((edge: any) => {
      return activeNodeIds.has(edge.source) && activeNodeIds.has(edge.target);
    });

    setNodes(filteredNodes);
    setEdges(filteredEdges);
  }, [filters, rawNodes, rawEdges, loading, setNodes, setEdges]);

  const onNodeClick = (_e: any, node: any) => {
    setSelectedNode(node);
  };

  const handleFilterToggle = (key: keyof typeof filters) => {
    setFilters(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p>Mapping relationship graph nodes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col gap-6 w-full h-[calc(100vh-80px)]">
      {/* Top Banner */}
      <div className="flex justify-between items-center shrink-0">
        <div>
          <h1 className="text-3xl font-extrabold font-outfit text-white">Graph Explorer</h1>
          <p className="text-sm text-muted">Click nodes to investigate cross-domain cascading links.</p>
        </div>
      </div>

      {/* Workspace */}
      <div className="flex-1 flex flex-col lg:flex-row gap-6 relative min-h-0">
        {/* Left Side: Filter Options */}
        <div className="w-full lg:w-56 glass p-5 rounded-2xl flex flex-col gap-4 shrink-0 justify-between">
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-white font-outfit border-b border-white/5 pb-2">Filter Domains</h2>
            <div className="flex flex-col gap-3">
              {Object.entries(filters).map(([key, value]) => (
                <label key={key} className="flex items-center gap-2.5 text-xs text-muted cursor-pointer hover:text-white transition-all select-none">
                  <input 
                    type="checkbox" 
                    checked={value}
                    onChange={() => handleFilterToggle(key as keyof typeof filters)}
                    className="rounded border-white/10 bg-white/5 text-primary focus:ring-0 focus:ring-offset-0 cursor-pointer"
                  />
                  <span className="capitalize">{key}s</span>
                </label>
              ))}
            </div>
          </div>
          
          <div className="text-[10px] text-muted leading-relaxed bg-white/5 p-3 rounded-xl border border-white/5">
            <span className="text-secondary font-bold">Pink animated paths</span> indicate high-probability correlation events identified by GPU similarity scans.
          </div>
        </div>

        {/* Center: React Flow Canvas */}
        <div className="flex-1 glass rounded-2xl relative overflow-hidden border border-white/5 min-h-[400px]">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onNodeClick={onNodeClick}
            nodeTypes={nodeTypes}
            fitView
            minZoom={0.2}
            maxZoom={1.5}
          >
            <Background color="rgba(255,255,255,0.06)" gap={20} size={1} />
            <Controls className="!bg-[#0F111C] !border-white/10" />
            <MiniMap 
              nodeColor={(n: any) => {
                if (n.type === "incident") return "#EF4444";
                if (n.type === "commit") return "#10B981";
                if (n.type === "ticket") return "#3B82F6";
                if (n.type === "support") return "#F59E0B";
                if (n.type === "service") return "#8B5CF6";
                return "#94A3B8";
              }}
              maskColor="rgba(5, 6, 11, 0.7)"
              className="!bg-[#0F111C] !border-white/10"
            />
          </ReactFlow>
        </div>

        {/* Right Side: Details Inspector Panel */}
        {selectedNode && (
          <div className="w-full lg:w-72 glass p-5 rounded-2xl flex flex-col gap-4 animate-slideIn shrink-0">
            <div className="flex justify-between items-center border-b border-white/5 pb-2">
              <h2 className="text-sm font-bold text-white font-outfit">Node Inspector</h2>
              <button 
                onClick={() => setSelectedNode(null)} 
                className="text-xs text-muted hover:text-white"
              >
                Close &times;
              </button>
            </div>

            <div className="flex flex-col gap-3.5 text-xs">
              <div>
                <span className="text-[10px] text-muted uppercase font-bold tracking-wider">Node ID</span>
                <p className="font-semibold text-white mt-0.5">{selectedNode.id}</p>
              </div>

              <div>
                <span className="text-[10px] text-muted uppercase font-bold tracking-wider">Category</span>
                <span className="px-2 py-0.5 bg-primary/10 border border-primary/20 text-primary text-[10px] font-semibold uppercase rounded-full inline-block mt-0.5">
                  {selectedNode.type}
                </span>
              </div>

              {selectedNode.data.title && (
                <div>
                  <span className="text-[10px] text-muted uppercase font-bold tracking-wider">Summary</span>
                  <p className="text-white font-medium mt-0.5">{selectedNode.data.title}</p>
                </div>
              )}

              {selectedNode.data.severity && (
                <div>
                  <span className="text-[10px] text-muted uppercase font-bold tracking-wider">Severity</span>
                  <span className={`px-2 py-0.5 text-[10px] font-semibold uppercase rounded-full inline-block mt-0.5 ${
                    selectedNode.data.severity === "CRITICAL" ? "bg-red-500/10 text-red-400 border border-red-500/20" : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                  }`}>
                    {selectedNode.data.severity}
                  </span>
                </div>
              )}

              {selectedNode.data.service && (
                <div>
                  <span className="text-[10px] text-muted uppercase font-bold tracking-wider">Associated Service</span>
                  <p className="text-white mt-0.5 font-semibold">{selectedNode.data.service}</p>
                </div>
              )}

              {selectedNode.data.timestamp && (
                <div>
                  <span className="text-[10px] text-muted uppercase font-bold tracking-wider">Time Detected</span>
                  <p className="text-muted mt-0.5">{selectedNode.data.timestamp}</p>
                </div>
              )}

              {selectedNode.data.files_changed && (
                <div>
                  <span className="text-[10px] text-muted uppercase font-bold tracking-wider">Files Altered</span>
                  <p className="font-mono text-[10px] text-emerald-400 bg-white/5 p-2 rounded-lg border border-white/5 mt-0.5">
                    {selectedNode.data.files_changed}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
