import { API_BASE_URL } from "../config";
import { getClientDashboard, getClientGraph, runClientChat, runClientBenchmark } from "./clientEngine";

export async function fetchDashboard() {
  try {
    const res = await fetch(`${API_BASE_URL}/dashboard`);
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn("FastAPI backend unreachable. Falling back to local Client Engine.", err);
    return getClientDashboard();
  }
}

export async function fetchGraph() {
  try {
    const res = await fetch(`${API_BASE_URL}/graph`);
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn("FastAPI backend unreachable. Falling back to local Client Engine.", err);
    return getClientGraph();
  }
}

export async function fetchChat(message: string) {
  try {
    const res = await fetch(`${API_BASE_URL}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    const data = await res.json();
    return data.response;
  } catch (err) {
    console.warn("FastAPI backend unreachable. Falling back to local Client Engine.", err);
    return runClientChat(message);
  }
}

export async function fetchBenchmark(scale: number) {
  try {
    const res = await fetch(`${API_BASE_URL}/benchmark?rows=${scale}`);
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn("FastAPI backend unreachable. Falling back to local Client Engine.", err);
    return runClientBenchmark(scale);
  }
}
