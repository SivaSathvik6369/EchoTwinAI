import type { Metadata } from "next";
import "./globals.css";
import Link from "next/link";

export const metadata: Metadata = {
  title: "EchoTwin AI - Cross-Domain Organizational Intelligence Platform",
  description: "Correlate server metrics, incident logs, support chats, git commits, and Jira issues into a unified intelligence graph using GPU-acceleration and Gemini analysis.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="antialiased min-h-screen flex flex-col md:flex-row overflow-x-hidden bg-[#05060B]">
        {/* Navigation Sidebar */}
        <aside className="w-full md:w-64 glass border-r border-border md:min-h-screen flex flex-col justify-between shrink-0 p-6 z-10">
          <div>
            {/* Logo */}
            <div className="mb-8 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-primary to-secondary flex items-center justify-center font-bold text-lg text-white shadow-[0_0_15px_rgba(139,92,246,0.5)]">
                ET
              </div>
              <div>
                <h1 className="font-semibold text-lg text-white leading-none font-outfit">EchoTwin AI</h1>
                <span className="text-[10px] text-muted tracking-wider uppercase">Enterprise Graph</span>
              </div>
            </div>

            {/* Menu Links */}
            <nav className="space-y-1.5">
              <Link 
                href="/" 
                className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-muted hover:text-white hover:bg-white/5 transition-all"
                id="nav-landing"
              >
                🏠 Home
              </Link>
              <Link 
                href="/upload" 
                className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-muted hover:text-white hover:bg-white/5 transition-all"
                id="nav-upload"
              >
                📤 Upload Center
              </Link>
              <Link 
                href="/dashboard" 
                className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-muted hover:text-white hover:bg-white/5 transition-all"
                id="nav-dashboard"
              >
                📊 Analytics Dashboard
              </Link>
              <Link 
                href="/graph" 
                className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-muted hover:text-white hover:bg-white/5 transition-all"
                id="nav-graph"
              >
                🕸️ Graph Explorer
              </Link>
              <Link 
                href="/benchmark" 
                className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-muted hover:text-white hover:bg-white/5 transition-all"
                id="nav-benchmark"
              >
                ⚡ GPU Benchmark
              </Link>
              <Link 
                href="/chat" 
                className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-muted hover:text-white hover:bg-white/5 transition-all"
                id="nav-chat"
              >
                💬 AI Assistant
              </Link>
            </nav>
          </div>

          {/* Footer info */}
          <div className="mt-8 pt-4 border-t border-white/5 text-[11px] text-muted/60 space-y-1">
            <p>GPU Engine: RAPIDS cuDF ready</p>
            <p>Gemini LLM: Context Linked</p>
            <p>© 2026 EchoTwin AI SRE</p>
          </div>
        </aside>

        {/* Main Work Area */}
        <main className="flex-1 relative flex flex-col min-h-screen overflow-y-auto px-4 md:px-8 py-8">
          <div className="glow-bg top-[-100px] right-[-100px]" />
          {children}
        </main>
      </body>
    </html>
  );
}
