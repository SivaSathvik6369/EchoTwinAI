"use client";

import { useState, useRef, useEffect } from "react";
import { fetchChat } from "@/lib/api";

interface Message {
  sender: "user" | "ai";
  text: string;
  timestamp: Date;
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: "ai",
      text: "**Welcome to EchoTwin AI Assistant!**\n\nI have processed the incident log graph. You can ask me questions about cascading root causes, operational risks, or node connectivity.\n\nTry clicking one of the suggested prompts below to start.",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const suggestedPrompts = [
    "Why did this incident occur?",
    "Show similar historical events.",
    "Summarize the biggest operational risks.",
    "Which systems are most connected?"
  ];

  const handleSend = async (messageText: string) => {
    if (!messageText.trim()) return;

    // Add user message
    const userMsg: Message = { sender: "user", text: messageText, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const response = await fetchChat(messageText);
      const aiMsg: Message = {
        sender: "ai",
        text: response || "No response received.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        { sender: "ai", text: `❌ Chat engine error: ${err.message}`, timestamp: new Date() }
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // Very basic helper to render markdown lists/bold text as HTML
  const formatMarkdown = (text: string) => {
    return text.split("\n").map((line, idx) => {
      let content = line;
      
      // Handle Bold text **text**
      const boldRegex = /\*\*(.*?)\*\*/g;
      content = content.replace(boldRegex, "<strong>$1</strong>");

      // Handle bullet points
      if (content.startsWith("* ")) {
        return <li key={idx} className="ml-4 list-disc text-sm text-gray-200" dangerouslySetInnerHTML={{ __html: content.substring(2) }} />;
      }
      if (content.startsWith("- ")) {
        return <li key={idx} className="ml-4 list-disc text-sm text-gray-200" dangerouslySetInnerHTML={{ __html: content.substring(2) }} />;
      }

      // Handle numbers
      if (/^\d+\.\s/.test(content)) {
        const dotIdx = content.indexOf(".");
        return <li key={idx} className="ml-4 list-decimal text-sm text-gray-200" dangerouslySetInnerHTML={{ __html: content.substring(dotIdx + 1) }} />;
      }

      if (!content.trim()) return <div key={idx} className="h-2" />;

      return <p key={idx} className="text-sm text-gray-200 leading-relaxed" dangerouslySetInnerHTML={{ __html: content }} />;
    });
  };

  return (
    <div className="flex-1 flex flex-col gap-6 max-w-4xl mx-auto w-full h-[calc(100vh-80px)] min-h-0">
      {/* Title block */}
      <div className="shrink-0">
        <h1 className="text-3xl font-extrabold font-outfit text-white">AI Assistant</h1>
        <p className="text-sm text-muted">Ask Gemini to investigate root causes and systems dependencies.</p>
      </div>

      {/* Chat Space */}
      <div className="flex-1 glass rounded-2xl flex flex-col min-h-0 border border-white/5 relative overflow-hidden">
        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((msg, index) => (
            <div 
              key={index}
              className={`flex flex-col max-w-[80%] ${msg.sender === "user" ? "ml-auto items-end" : "mr-auto items-start animate-fadeIn"}`}
            >
              <div 
                className={`p-4 rounded-2xl border text-sm ${
                  msg.sender === "user" 
                    ? "bg-primary border-primary-dark text-white rounded-br-none" 
                    : "bg-white/5 border-white/5 text-gray-100 rounded-bl-none"
                }`}
              >
                <div className="space-y-2">
                  {formatMarkdown(msg.text)}
                </div>
              </div>
              <span className="text-[9px] text-muted/60 mt-1 px-1">
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          ))}

          {loading && (
            <div className="mr-auto flex items-center gap-3 bg-white/5 border border-white/5 p-4 rounded-2xl rounded-bl-none max-w-[200px] animate-pulse">
              <span className="flex gap-1">
                <span className="w-1.5 h-1.5 bg-muted rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-1.5 h-1.5 bg-muted rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-1.5 h-1.5 bg-muted rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </span>
              <span className="text-xs text-muted">Gemini analyzing...</span>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Suggested prompts area */}
        <div className="shrink-0 p-4 border-t border-white/5 bg-white/5 flex flex-wrap gap-2.5">
          {suggestedPrompts.map((prompt) => (
            <button
              key={prompt}
              onClick={() => handleSend(prompt)}
              disabled={loading}
              className="px-3 py-1.5 rounded-xl bg-[#05060B] border border-white/10 hover:border-primary text-[11px] text-muted hover:text-white transition-all disabled:opacity-50"
            >
              💬 {prompt}
            </button>
          ))}
        </div>

        {/* Input area */}
        <div className="shrink-0 p-4 bg-white/5 border-t border-white/5 flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend(input)}
            placeholder="Ask a question about the SRE incident logs..."
            disabled={loading}
            className="flex-1 bg-[#05060B] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary placeholder:text-muted/50 disabled:opacity-50"
          />
          <button
            onClick={() => handleSend(input)}
            disabled={loading || !input.trim()}
            className="py-3 px-6 bg-primary hover:bg-primary-dark disabled:opacity-50 text-white text-sm font-semibold rounded-xl transition-all"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
}
