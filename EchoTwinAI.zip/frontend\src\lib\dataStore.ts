// Types definition
export interface Incident {
  incident_id: string;
  timestamp: string;
  service: string;
  severity: string;
  message: string;
  employee_id: string;
}

export interface JiraTicket {
  ticket_id: string;
  created_time: string;
  updated_time: string;
  summary: string;
  description: string;
  assignee_id: string;
  service: string;
  status: string;
  priority: string;
}

export interface GitCommit {
  commit_sha: string;
  timestamp: string;
  author: string;
  message: string;
  files_changed: string;
  service: string;
}

export interface ServerMetric {
  timestamp: string;
  server_name: string;
  cpu_utilization: number;
  memory_utilization: number;
  active_connections: number;
  service: string;
}

export interface SupportChat {
  support_id: string;
  timestamp: string;
  customer_id: string;
  category: string;
  message: string;
  status: string;
  agent_id: string;
}

// Default Outage Data
const baseTime = "2026-07-06T12:00:00Z";

export const initialIncidents: Incident[] = [
  { incident_id: "INC-101", timestamp: "2026-07-06T02:00:00Z", service: "email-delivery", severity: "WARNING", message: "SMTP connection slow latency check failed", employee_id: "EMP002" },
  { incident_id: "INC-102", timestamp: "2026-07-06T07:00:00Z", service: "frontend-web", severity: "INFO", message: "Static assets bundle deployed", employee_id: "EMP003" },
  { incident_id: "INC-103", timestamp: "2026-07-06T12:00:00Z", service: "auth-service", severity: "CRITICAL", message: "Database connection pool exhausted. DB connection timeout in auth-service.", employee_id: "EMP001" },
  { incident_id: "INC-104", timestamp: "2026-07-06T12:02:00Z", service: "frontend-web", severity: "ERROR", message: "HTTP 504 Gateway Timeout requesting auth token validation from auth-service", employee_id: "EMP003" },
  { incident_id: "INC-105", timestamp: "2026-07-06T12:05:00Z", service: "payment-gateway", severity: "ERROR", message: "Transaction failed: cannot authenticate payment payload session token expired", employee_id: "EMP002" },
  { incident_id: "INC-106", timestamp: "2026-07-06T12:08:00Z", service: "database-core", severity: "WARNING", message: "Lock wait timeout exceeded in database-core backend transaction rollback", employee_id: "EMP001" }
];

export const initialJiraTickets: JiraTicket[] = [
  { ticket_id: "JIRA-402", created_time: "2026-07-03T10:00:00Z", updated_time: "2026-07-04T12:00:00Z", summary: "Styling issues on checkout screen", description: "Border alignment on mobile check-out form is misaligned", assignee_id: "EMP003", service: "frontend-web", status: "Done", priority: "Low" },
  { ticket_id: "JIRA-403", created_time: "2026-07-05T12:00:00Z", updated_time: "2026-07-06T08:00:00Z", summary: "Fix cache evictions", description: "Cache size exceeds limits occasionally, need eviction strategy", assignee_id: "EMP001", service: "auth-service", status: "In Progress", priority: "Medium" },
  { ticket_id: "JIRA-404", created_time: "2026-07-06T12:10:00Z", updated_time: "2026-07-06T12:20:00Z", summary: "Critical: Auth service connection pool exhaustion crashes frontend gateway", description: "Users are locked out and HTTP 504 timeouts are flooding frontend logs. Investigating connection pool refactoring commit.", assignee_id: "EMP001", service: "auth-service", status: "Open", priority: "Highest" },
  { ticket_id: "JIRA-405", created_time: "2026-07-06T12:18:00Z", updated_time: "2026-07-06T12:18:00Z", summary: "Payment checkout service failing for all users", description: "Unable to process transactions since 12:00 PM. High priority failure reported from customer support.", assignee_id: "EMP002", service: "payment-gateway", status: "Open", priority: "Highest" }
];

export const initialGitCommits: GitCommit[] = [
  { commit_sha: "d3a5e12", timestamp: "2026-07-04T12:00:00Z", author: "bob@company.com", message: "Updated payment form UI validations", files_changed: "frontend/src/payment.tsx", service: "frontend-web" },
  { commit_sha: "f8a12e9", timestamp: "2026-07-05T12:00:00Z", author: "charlie@company.com", message: "Added indices on transactions table", files_changed: "db/migrations/032_idx.sql", service: "database-core" },
  { commit_sha: "9a38fcd", timestamp: "2026-07-06T09:00:00Z", author: "alice@company.com", message: "Optimized token parsing cache in gateway", files_changed: "auth/cache.py", service: "auth-service" },
  { commit_sha: "b5e91a2", timestamp: "2026-07-06T11:45:00Z", author: "alice@company.com", message: "Refactored DB connection pool timeout in auth-service configuration", files_changed: "auth/config.py, auth/db.py", service: "auth-service" }
];

export const initialServerMetrics: ServerMetric[] = [
  { timestamp: "2026-07-06T11:00:00Z", server_name: "srv-auth-01", cpu_utilization: 24.5, memory_utilization: 42.1, active_connections: 135, service: "auth-service" },
  { timestamp: "2026-07-06T11:30:00Z", server_name: "srv-auth-01", cpu_utilization: 26.2, memory_utilization: 44.5, active_connections: 142, service: "auth-service" },
  { timestamp: "2026-07-06T12:00:00Z", server_name: "srv-auth-01", cpu_utilization: 98.5, memory_utilization: 92.1, active_connections: 8, service: "auth-service" },
  { timestamp: "2026-07-06T12:05:00Z", server_name: "srv-auth-01", cpu_utilization: 99.1, memory_utilization: 93.4, active_connections: 5, service: "auth-service" },
  { timestamp: "2026-07-06T12:00:00Z", server_name: "srv-db-01", cpu_utilization: 87.4, memory_utilization: 79.5, active_connections: 450, service: "database-core" }
];

export const initialSupportChats: SupportChat[] = [
  { support_id: "SUP-801", timestamp: "2026-07-06T08:00:00Z", customer_id: "CUST-903", category: "Billing", message: "Where can I download my invoice for last month?", status: "Resolved", agent_id: "EMP002" },
  { support_id: "SUP-802", timestamp: "2026-07-06T12:04:00Z", customer_id: "CUST-901", category: "Authentication Failure", message: "I am trying to log into the dashboard but it gives me a gateway timeout error. Please fix!", status: "Open", agent_id: "EMP003" },
  { support_id: "SUP-803", timestamp: "2026-07-06T12:07:00Z", customer_id: "CUST-902", category: "Checkout Loop", message: "Whenever I click buy, the loading spinner spins forever, then says token expired. I tried 3 times.", status: "Open", agent_id: "EMP002" },
  { support_id: "SUP-804", timestamp: "2026-07-06T12:12:00Z", customer_id: "CUST-904", category: "Login Outage", message: "The entire app is down. Getting blank screen and auth connection errors. Are you experiencing an outage?", status: "Open", agent_id: "EMP003" }
];

// Global in-memory state for Netlify serverless functions session
export let store = {
  incidents: [...initialIncidents],
  jira: [...initialJiraTickets],
  commits: [...initialGitCommits],
  metrics: [...initialServerMetrics],
  support: [...initialSupportChats]
};

export function resetStore() {
  store.incidents = [...initialIncidents];
  store.jira = [...initialJiraTickets];
  store.commits = [...initialGitCommits];
  store.metrics = [...initialServerMetrics];
  store.support = [...initialSupportChats];
}
