import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "#05060B",
        card: "rgba(15, 17, 28, 0.65)",
        border: "rgba(255, 255, 255, 0.08)",
        primary: {
          DEFAULT: "#8B5CF6",
          dark: "#7C3AED",
        },
        secondary: "#EC4899",
        accent: "#10B981",
        muted: "#94A3B8",
      },
      backdropFilter: {
        none: 'none',
        blur: 'blur(20px)',
      },
    },
  },
  plugins: [],
  darkMode: "class"
};
export default config;
