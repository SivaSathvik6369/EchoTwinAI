import os
import json
import pandas as pd
from google.cloud import storage, bigquery
from google.oauth2 import service_account

# Local directories configuration
LOCAL_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
os.makedirs(LOCAL_DATA_DIR, exist_ok=True)

class CloudManager:
    def __init__(self):
        self.project_id = os.getenv("GCP_PROJECT_ID")
        self.gcs_bucket_name = os.getenv("GCP_GCS_BUCKET")
        self.credentials_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
        
        self.credentials = None
        self.storage_client = None
        self.bq_client = None
        self.is_gcp_configured = False
        
        # Initialize client if configurations are supplied
        if self.credentials_path and os.path.exists(self.credentials_path):
            try:
                self.credentials = service_account.Credentials.from_service_account_file(self.credentials_path)
                self.storage_client = storage.Client(credentials=self.credentials, project=self.project_id)
                self.bq_client = bigquery.Client(credentials=self.credentials, project=self.project_id)
                self.is_gcp_configured = True
                print("Successfully connected to Google Cloud Services (GCS & BigQuery)")
            except Exception as e:
                print(f"Error authenticating with GCP credentials: {e}. Falling back to offline local mode.")
        else:
            # Try default credentials
            try:
                self.storage_client = storage.Client()
                self.bq_client = bigquery.Client()
                self.is_gcp_configured = True
                print("Connected to Google Cloud Services using Application Default Credentials.")
            except Exception:
                print("No GCP credentials found. Running in offline/local storage mode.")

    # -------------------------------------------------------------
    # Google Cloud Storage (GCS) Interface
    # -------------------------------------------------------------
    def upload_file(self, local_file_path, destination_blob_name):
        """
        Uploads a file to GCS bucket. Fallback to saving copy locally.
        """
        basename = os.path.basename(local_file_path)
        local_dest = os.path.join(LOCAL_DATA_DIR, destination_blob_name or basename)
        os.makedirs(os.path.dirname(local_dest), exist_ok=True)
        
        # Save a local copy regardless
        if os.path.abspath(local_file_path) != os.path.abspath(local_dest):
            with open(local_file_path, "rb") as src, open(local_dest, "wb") as dst:
                dst.write(src.read())

        if self.is_gcp_configured and self.gcs_bucket_name:
            try:
                bucket = self.storage_client.bucket(self.gcs_bucket_name)
                blob = bucket.blob(destination_blob_name)
                blob.upload_from_filename(local_file_path)
                print(f"Uploaded {local_file_path} to GCS bucket {self.gcs_bucket_name} as {destination_blob_name}")
                return {
                    "success": True,
                    "storage_provider": "gcs",
                    "uri": f"gs://{self.gcs_bucket_name}/{destination_blob_name}"
                }
            except Exception as e:
                print(f"GCS Upload failed: {e}")
                
        return {
            "success": True,
            "storage_provider": "local",
            "uri": f"file:///{local_dest.replace('\\', '/')}"
        }

    def download_file(self, blob_name, local_file_path):
        """
        Downloads file from GCS, fallback to copying from local store.
        """
        if self.is_gcp_configured and self.gcs_bucket_name:
            try:
                bucket = self.storage_client.bucket(self.gcs_bucket_name)
                blob = bucket.blob(blob_name)
                os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
                blob.download_to_filename(local_file_path)
                return True
            except Exception as e:
                print(f"GCS Download failed: {e}")
                
        # Local fallback check
        local_src = os.path.join(LOCAL_DATA_DIR, blob_name)
        if os.path.exists(local_src) and os.path.abspath(local_src) != os.path.abspath(local_file_path):
            with open(local_src, "rb") as src, open(local_file_path, "wb") as dst:
                dst.write(src.read())
            return True
            
        return os.path.exists(local_file_path)

    # -------------------------------------------------------------
    # BigQuery Interface
    # -------------------------------------------------------------
    def load_df_to_bigquery(self, df, table_id, write_disposition="WRITE_TRUNCATE"):
        """
        Loads a Pandas DataFrame to a BigQuery table. Fallback to saving as CSV.
        """
        local_csv_path = os.path.join(LOCAL_DATA_DIR, f"{table_id.replace('.', '_')}.csv")
        df.to_csv(local_csv_path, index=False)
        
        if self.is_gcp_configured:
            try:
                job_config = bigquery.LoadJobConfig(write_disposition=write_disposition)
                job = self.bq_client.load_table_from_dataframe(df, table_id, job_config=job_config)
                job.result()  # Wait for load to finish
                print(f"Loaded {len(df)} rows into BigQuery table: {table_id}")
                return {
                    "success": True,
                    "provider": "bigquery",
                    "table": table_id
                }
            except Exception as e:
                print(f"BigQuery load failed: {e}")
                
        return {
            "success": True,
            "provider": "local_csv",
            "path": local_csv_path
        }

    def execute_bq_query(self, query_string):
        """
        Executes a BigQuery query. Offline fallback loads local CSV matching tables.
        """
        if self.is_gcp_configured:
            try:
                query_job = self.bq_client.query(query_string)
                df = query_job.to_dataframe()
                return df
            except Exception as e:
                print(f"BigQuery query failed: {e}. Trying local fallback.")
                
        # Local search fallback (mocking simple query or loading saved table CSVs)
        # Parses simple 'FROM table_name' to load matching csv
        words = query_string.lower().split()
        table_name = None
        for i, word in enumerate(words):
            if word == "from" and i + 1 < len(words):
                table_name = words[i + 1].strip("`;")
                break
                
        if table_name:
            # Map table name to local csv filename
            local_csv = os.path.join(LOCAL_DATA_DIR, f"{table_name.replace('.', '_')}.csv")
            if os.path.exists(local_csv):
                return pd.read_csv(local_csv)
                
        print(f"Offline mode: could not resolve BQ query or match local CSV for query: {query_string}")
        return pd.DataFrame()
