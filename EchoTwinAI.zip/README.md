# EchoTwin AI
> **Cross-Domain Organizational Intelligence Platform**

Organizations generate millions of disconnected events every day (incident logs, git commits, server metrics, support tickets, etc.). **EchoTwin AI** correlates these events into a unified, interactive intelligence graph, helping site reliability engineers (SREs) and system architects discover root-cause incident patterns and mitigate operational risks.

---

## 🚀 Key Features

1. **GPU-Accelerated Analytics**: Ingests multiple CSV/JSON datasets and runs timestamp normalizations, data cleaning, and cross-table joins using **NVIDIA RAPIDS (cuDF)** (gracefully falls back to CPU Pandas when running locally without an NVIDIA GPU).
2. **Interactive Relationship Graph**: Computes correlations using temporal proximity (e.g., within 15 mins), shared services, common author/assignee tags, and keyword TF-IDF similarities. Rendered via **React Flow**.
3. **Gemini SRE Chatbot**: Connects directly to the Gemini API to explain cascading failures (e.g. why did the checkout system fail?), list operational risks, and recommend mitigations based on active graph context.
4. **Performance Benchmarking**: Displays execution times, rows/second throughput, memory savings, and speedup gains when comparing Pandas (CPU) vs. cuDF (GPU).
5. **GCP BigQuery & Storage Support**: Ingestion layers connect to Google Cloud Storage (GCS) and BigQuery, with local filesystem folder fallbacks for offline running.
6. **Looker Ready Metadata**: Generates LookML dimension schemas dynamically on the dashboard.

---

## 🛠️ Tech Stack

- **Frontend**: Next.js 15, TypeScript, Tailwind CSS, Recharts, React Flow (v12 `@xyflow/react`), Framer Motion
- **Backend**: FastAPI (Python 3.12)
- **Data Engine**: NVIDIA RAPIDS, cuDF, Pandas, NumPy
- **AI Engine**: Google Gemini API (`google-generativeai`)
- **Cloud Layer**: Google Cloud Storage, Google BigQuery

---

## 📂 Project Structure

```text
EchoTwinAI/
├── backend/
│   ├── cloud/             # GCS & BigQuery bindings
│   ├── dashboard/         # Timelines and heatmaps aggregations
│   ├── gemini/            # Gemini client API & heuristic fallbacks
│   ├── gpu_engine/        # RAPIDS/cuDF data preprocessing & benchmarks
│   ├── graph_engine/      # Correlation logic & React Flow builders
│   ├── sample_data/       # Outage dataset generators
│   ├── main.py            # FastAPI main router
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── app/           # Next.js App Router views (dashboard, upload, graph, chat, benchmark)
│   │   └── components/
│   ├── package.json
│   ├── tailwind.config.ts
│   ├── postcss.config.js
│   ├── tsconfig.json
│   └── Dockerfile
└── docker-compose.yml
```

---

## 🏃 Run Instructions

### Option 1: Run Locally (Fastest)

#### 1. Setup Backend
1. Open a terminal and navigate to the backend folder:
   ```bash
   cd backend
   ```
2. Create and activate a python virtual environment:
   ```bash
   python -m venv venv
   # Windows:
   .\venv\Scripts\activate
   # Linux/macOS:
   source venv/bin/activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Set optional env variables (e.g., if you have a Gemini Key or GCP details):
   ```bash
   set GEMINI_API_KEY=your_gemini_api_key
   ```
5. Run the FastAPI application:
   ```bash
   python main.py
   ```
   *The server will boot on `http://localhost:8000`. It will automatically generate the default synthetic outage datasets in memory.*

#### 2. Setup Frontend
1. Open a new terminal and navigate to the frontend folder:
   ```bash
   cd frontend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run the development server:
   ```bash
   npm run dev
   ```
   *The frontend dashboard will boot on `http://localhost:3000`.*

---

### Option 2: Run via Docker Compose

Bring up the entire platform in a single command (requires Docker installed):

```bash
# In the root EchoTwinAI directory
docker-compose up --build
```
- Access the **UI dashboard**: `http://localhost:3000`
- Access the **API backend**: `http://localhost:8000`

---

## 📑 Cascading Outage Scenario

EchoTwin AI pre-loads an operational SRE incident timeline for demo purposes:
- **11:45 AM**: Alice Smith (`EMP001`) commits code (`b5e91a2`) modifying connection pool properties in the `auth-service`.
- **12:00 PM**: Server CPU usage on `srv-auth-01` spikes to 98%, triggering incident alert `INC-103`: *Database connection pool exhausted*.
- **12:02 PM**: Gateway failures propagate to `frontend-web` (`INC-104` HTTP 504 Timeout) and transaction checkout validation locks.
- **12:04 PM**: Customers submit support tickets complaining of auth failures; a critical Jira blocker (`JIRA-404`) is created.

*Navigate to the **AI Assistant** or **Graph Explorer** tabs to trace, analyze, and query these relationships.*
