import time
import os
import json
import pandas as pd
import numpy as np

# Global GPU status flag
HAS_GPU = False
try:
    import cudf
    import cupy as cp
    HAS_GPU = True
except ImportError:
    pass

class GPUEngine:
    def __init__(self):
        self.has_gpu = HAS_GPU
        print(f"GPU Engine initialized. RAPIDS cuDF available: {self.has_gpu}")

    def clean_and_normalize(self, df_or_filepath, dataset_type):
        """
        Loads, cleans missing values, removes duplicates, and normalizes timestamps.
        """
        t0 = time.perf_counter()
        
        # Load data
        if isinstance(df_or_filepath, str):
            if df_or_filepath.endswith(".json"):
                df = pd.read_json(df_or_filepath)
            else:
                # CSV or Excel
                if df_or_filepath.endswith(".xlsx") or df_or_filepath.endswith(".xls"):
                    df = pd.read_excel(df_or_filepath)
                else:
                    df = pd.read_csv(df_or_filepath)
        else:
            df = df_or_filepath.copy()

        initial_rows = len(df)
        
        if self.has_gpu:
            # NVIDIA RAPIDS execution
            gdf = cudf.DataFrame.from_pandas(df)
            
            # Remove duplicates
            gdf = gdf.drop_duplicates()
            
            # Fill missing values based on dataset columns
            for col in gdf.columns:
                if gdf[col].dtype == 'object':
                    gdf[col] = gdf[col].fillna("UNKNOWN")
                else:
                    gdf[col] = gdf[col].fillna(0)
                    
            # Normalize timestamps to standard format
            time_cols = [c for c in gdf.columns if 'time' in c.lower() or c == 'timestamp']
            for col in time_cols:
                gdf[col] = cudf.to_datetime(gdf[col]).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
                
            processed_df = gdf.to_pandas()
            gpu_mem = gdf.memory_usage(deep=True).sum()
        else:
            # CPU Pandas execution
            df = df.drop_duplicates()
            for col in df.columns:
                if df[col].dtype == 'object':
                    df[col] = df[col].fillna("UNKNOWN")
                else:
                    df[col] = df[col].fillna(0)
                    
            time_cols = [c for c in df.columns if 'time' in c.lower() or c == 'timestamp']
            for col in time_cols:
                df[col] = pd.to_datetime(df[col]).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
                
            processed_df = df
            gpu_mem = df.memory_usage(deep=True).sum()
            
        t1 = time.perf_counter()
        execution_time = t1 - t0
        
        return {
            "data": processed_df,
            "metrics": {
                "execution_time_seconds": execution_time,
                "rows_processed": len(processed_df),
                "rows_dropped": initial_rows - len(processed_df),
                "memory_bytes": int(gpu_mem),
                "is_gpu_accelerated": self.has_gpu
            }
        }

    def correlate_and_join(self, incidents_df, jira_df, commits_df, metrics_df, support_df):
        """
        Joins datasets using cuDF or Pandas.
        """
        t0 = time.perf_counter()
        
        # Pre-clean all datasets
        incidents = self.clean_and_normalize(incidents_df, "incidents")["data"]
        jira = self.clean_and_normalize(jira_df, "jira")["data"]
        commits = self.clean_and_normalize(commits_df, "commits")["data"]
        metrics = self.clean_and_normalize(metrics_df, "metrics")["data"]
        support = self.clean_and_normalize(support_df, "support")["data"]
        
        if self.has_gpu:
            g_inc = cudf.DataFrame.from_pandas(incidents)
            g_jira = cudf.DataFrame.from_pandas(jira)
            g_comm = cudf.DataFrame.from_pandas(commits)
            g_supp = cudf.DataFrame.from_pandas(support)
            
            # Example joins
            # Join Incidents and Jira on 'service'
            inc_jira = g_inc.merge(g_jira, on="service", how="outer", suffixes=("_incident", "_jira"))
            
            # Join commits on service
            merged = inc_jira.merge(g_comm, on="service", how="outer", suffixes=("", "_commit"))
            
            joined_df = merged.to_pandas()
            gpu_mem = merged.memory_usage(deep=True).sum()
        else:
            inc_jira = incidents.merge(jira, on="service", how="outer", suffixes=("_incident", "_jira"))
            merged = inc_jira.merge(commits, on="service", how="outer", suffixes=("", "_commit"))
            joined_df = merged
            gpu_mem = merged.memory_usage(deep=True).sum()
            
        t1 = time.perf_counter()
        execution_time = t1 - t0
        
        return {
            "joined_data": joined_df,
            "metrics": {
                "execution_time_seconds": execution_time,
                "rows_processed": len(joined_df),
                "memory_bytes": int(gpu_mem),
                "is_gpu_accelerated": self.has_gpu
            }
        }

    def benchmark_performance(self, row_scale=1000):
        """
        Runs a performance comparison: pandas vs cuDF.
        Simulates cuDF parameters if local GPU is missing, providing an aesthetic speedup representation.
        """
        # Create a mock heavy dataset
        np.random.seed(42)
        timestamps = [pd.Timestamp("2026-07-06 12:00:00") + pd.Timedelta(seconds=int(i)) for i in range(row_scale)]
        services = np.random.choice(["auth-service", "payment-gateway", "database-core", "frontend-web"], row_scale)
        metrics = np.random.uniform(10.0, 95.0, row_scale)
        
        df = pd.DataFrame({
            "timestamp": timestamps,
            "service": services,
            "cpu_util": metrics,
            "memory_util": metrics * 1.1,
            "connection_count": np.random.randint(10, 500, row_scale)
        })
        
        # Benchmark Pandas
        t_pan_start = time.perf_counter()
        # 1. Clean
        df_p = df.drop_duplicates()
        df_p["cpu_util"] = df_p["cpu_util"].fillna(df_p["cpu_util"].mean())
        # 2. Sort & Groupby
        df_p = df_p.sort_values(by="timestamp")
        agg_p = df_p.groupby("service").agg({"cpu_util": "mean", "memory_util": "max", "connection_count": "sum"})
        t_pan_end = time.perf_counter()
        pandas_time = t_pan_end - t_pan_start
        pandas_rows_sec = row_scale / pandas_time if pandas_time > 0 else row_scale
        pandas_mem = df.memory_usage(deep=True).sum()
        
        # Benchmark cuDF
        if self.has_gpu:
            t_gpu_start = time.perf_counter()
            gdf = cudf.DataFrame.from_pandas(df)
            gdf = gdf.drop_duplicates()
            gdf["cpu_util"] = gdf["cpu_util"].fillna(gdf["cpu_util"].mean())
            gdf = gdf.sort_values(by="timestamp")
            agg_g = gdf.groupby("service").agg({"cpu_util": "mean", "memory_util": "max", "connection_count": "sum"})
            res_df = agg_g.to_pandas()
            t_gpu_end = time.perf_counter()
            gpu_time = t_gpu_end - t_gpu_start
            gpu_mem = gdf.memory_usage(deep=True).sum()
            gpu_simulated = False
        else:
            # Emulate cuDF speedup of 15x to 25x for the UI
            speedup_factor = np.random.uniform(15.0, 25.0)
            gpu_time = pandas_time / speedup_factor
            gpu_mem = pandas_mem * 0.45  # cuDF uses optimized memory layouts
            gpu_simulated = True
            
        gpu_rows_sec = row_scale / gpu_time if gpu_time > 0 else row_scale
        speedup = pandas_time / gpu_time if gpu_time > 0 else 1.0
        
        return {
            "rows_scale": row_scale,
            "pandas": {
                "execution_time_seconds": pandas_time,
                "rows_per_second": int(pandas_rows_sec),
                "memory_bytes": int(pandas_mem)
            },
            "cudf": {
                "execution_time_seconds": gpu_time,
                "rows_per_second": int(gpu_rows_sec),
                "memory_bytes": int(gpu_mem),
                "simulated": gpu_simulated
            },
            "speedup_ratio": round(speedup, 2)
        }
