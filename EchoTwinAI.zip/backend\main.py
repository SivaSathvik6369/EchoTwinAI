import os
import json
import pandas as pd
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Internal imports
from sample_data.generate_datasets import generate_all_datasets
from gpu_engine.engine import GPUEngine
from graph_engine.builder import GraphBuilder
from dashboard.analytics import DashboardAnalytics
from gemini.assistant import GeminiAssistant
from cloud.gcp import CloudManager

app = FastAPI(title="EchoTwin AI Backend", version="1.0.0")

# Setup CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global Application State
class AppState:
    def __init__(self):
        self.gpu_engine = GPUEngine()
        self.graph_builder = GraphBuilder()
        self.analytics = DashboardAnalytics()
        self.assistant = GeminiAssistant()
        self.cloud = CloudManager()
        
        self.data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Dataframes in memory
        self.incidents_df = None
        self.jira_df = None
        self.commits_df = None
        self.metrics_df = None
        self.support_df = None
        
        self.load_or_generate_default_data()

    def load_or_generate_default_data(self):
        """
        Populates memory with generated synthetic data if no active datasets exist.
        """
        # Paths to standard datasets
        files = {
            "incidents": ("incident_logs.csv", True),
            "jira": ("jira_tickets.csv", True),
            "commits": ("git_commits.csv", True),
            "metrics": ("server_metrics.csv", True),
            "support": ("customer_support.json", False)
        }
        
        # Check if all exist, if not generate them in data_dir
        needs_generation = False
        for key, (filename, is_csv) in files.items():
            path = os.path.join(self.data_dir, filename)
            if not os.path.exists(path):
                needs_generation = True
                break
                
        if needs_generation:
            print("Default synthetic datasets not found. Generating...")
            generate_all_datasets(self.data_dir)
            
        # Read files into dataframes
        try:
            self.incidents_df = pd.read_csv(os.path.join(self.data_dir, "incident_logs.csv"))
            self.jira_df = pd.read_csv(os.path.join(self.data_dir, "jira_tickets.csv"))
            self.commits_df = pd.read_csv(os.path.join(self.data_dir, "git_commits.csv"))
            self.metrics_df = pd.read_csv(os.path.join(self.data_dir, "server_metrics.csv"))
            self.support_df = pd.read_json(os.path.join(self.data_dir, "customer_support.json"))
            print("Loaded synthetic datasets into app memory successfully.")
        except Exception as e:
            print(f"Error loading datasets during startup: {e}")

state = AppState()

# Pydantic models
class ChatRequest(BaseModel):
    message: str

# -------------------------------------------------------------
# Endpoints
# -------------------------------------------------------------

@app.get("/")
def read_root():
    return {"name": "EchoTwin AI API", "status": "active", "has_gpu": state.gpu_engine.has_gpu}

@app.post("/upload")
async def upload_dataset(file: UploadFile = File(...), dataset_type: str = Form(...)):
    """
    Upload a CSV, Excel, or JSON dataset.
    Updates the local memory dataframe of the specified dataset_type.
    """
    valid_types = ["incidents", "jira", "commits", "metrics", "support"]
    if dataset_type not in valid_types:
        raise HTTPException(status_code=400, detail=f"Invalid dataset_type. Must be one of {valid_types}")
        
    filename = file.filename
    temp_path = os.path.join(state.data_dir, f"uploaded_{filename}")
    
    # Save the file stream locally
    try:
        with open(temp_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
            
        # Parse into DataFrame based on extension
        if filename.endswith(".json"):
            df = pd.read_json(temp_path)
        elif filename.endswith(".xlsx") or filename.endswith(".xls"):
            df = pd.read_excel(temp_path)
        else:
            df = pd.read_csv(temp_path)
            
        # Save copy to active dataset file path
        dest_filename = f"incident_logs.csv" if dataset_type == "incidents" else (
            f"jira_tickets.csv" if dataset_type == "jira" else (
                f"git_commits.csv" if dataset_type == "commits" else (
                    f"server_metrics.csv" if dataset_type == "metrics" else f"customer_support.json"
                )
            )
        )
        
        dest_path = os.path.join(state.data_dir, dest_filename)
        if dest_filename.endswith(".json"):
            df.to_json(dest_path, orient="records", indent=4)
        else:
            df.to_csv(dest_path, index=False)
            
        # Upload to Google Cloud Storage as secondary backup (runs offline fallback automatically)
        state.cloud.upload_file(dest_path, dest_filename)
        
        # Load to BigQuery table
        state.cloud.load_df_to_bigquery(df, f"echotwin_dataset.{dataset_type}")
        
        # Update App State memory
        if dataset_type == "incidents":
            state.incidents_df = df
        elif dataset_type == "jira":
            state.jira_df = df
        elif dataset_type == "commits":
            state.commits_df = df
        elif dataset_type == "metrics":
            state.metrics_df = df
        elif dataset_type == "support":
            state.support_df = df
            
        # Clean up temporary uploaded file
        if os.path.exists(temp_path):
            os.remove(temp_path)
            
        return {
            "success": True,
            "message": f"Successfully uploaded and parsed dataset '{filename}' as '{dataset_type}'",
            "rows_count": len(df),
            "columns": list(df.columns)
        }
        
    except Exception as e:
        if os.path.exists(temp_path):
            os.remove(temp_path)
        raise HTTPException(status_code=500, detail=f"Failed to process file: {str(e)}")

@app.post("/process")
def process_datasets():
    """
    Performs GPU Preprocessing (deduplication, normalization, timestamp alignments).
    Returns preprocessing time comparisons and rows summaries.
    """
    try:
        p_inc = state.gpu_engine.clean_and_normalize(state.incidents_df, "incidents")
        p_jira = state.gpu_engine.clean_and_normalize(state.jira_df, "jira")
        p_comm = state.gpu_engine.clean_and_normalize(state.commits_df, "commits")
        p_met = state.gpu_engine.clean_and_normalize(state.metrics_df, "metrics")
        p_sup = state.gpu_engine.clean_and_normalize(state.support_df, "support")
        
        # Join execution
        join_res = state.gpu_engine.correlate_and_join(
            state.incidents_df, state.jira_df, state.commits_df, state.metrics_df, state.support_df
        )
        
        # Aggregate statistics
        total_time = (
            p_inc["metrics"]["execution_time_seconds"] +
            p_jira["metrics"]["execution_time_seconds"] +
            p_comm["metrics"]["execution_time_seconds"] +
            p_met["metrics"]["execution_time_seconds"] +
            p_sup["metrics"]["execution_time_seconds"] +
            join_res["metrics"]["execution_time_seconds"]
        )
        
        # Update current state with cleaned values
        state.incidents_df = p_inc["data"]
        state.jira_df = p_jira["data"]
        state.commits_df = p_comm["data"]
        state.metrics_df = p_met["data"]
        state.support_df = p_sup["data"]
        
        return {
            "success": True,
            "total_execution_time_seconds": total_time,
            "is_gpu_accelerated": state.gpu_engine.has_gpu,
            "stages": {
                "incidents": p_inc["metrics"],
                "jira": p_jira["metrics"],
                "commits": p_comm["metrics"],
                "metrics": p_met["metrics"],
                "support": p_sup["metrics"],
                "correlation_join": join_res["metrics"]
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"GPU Preprocessing Pipeline failed: {str(e)}")

@app.get("/graph")
def get_correlation_graph():
    """
    Generates dynamic React Flow Node & Edge elements based on cross-domain event linkages.
    """
    try:
        graph = state.graph_builder.build_network_graph(
            state.incidents_df,
            state.jira_df,
            state.commits_df,
            state.metrics_df,
            state.support_df
        )
        return graph
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to compile correlation graph: {str(e)}")

@app.get("/dashboard")
def get_dashboard_data():
    """
    Prepares aggregated analytics metrics, timeline time series, and heatmaps.
    """
    try:
        stats = state.analytics.compute_summary_stats(
            state.incidents_df,
            state.jira_df,
            state.commits_df,
            state.metrics_df,
            state.support_df
        )
        timeline = state.analytics.generate_timeline_series(
            state.incidents_df,
            state.jira_df,
            state.commits_df,
            state.support_df
        )
        distributions = state.analytics.generate_distribution_charts(
            state.incidents_df,
            state.jira_df,
            state.commits_df,
            state.support_df
        )
        matrix = state.analytics.generate_correlation_matrix()
        
        # Looker-ready dataset structure metadata export
        looker_ready_metadata = {
            "schema_name": "EchoTwin Looker Dataset",
            "table_references": ["incident_logs", "jira_tickets", "git_commits", "server_metrics"],
            "lookml_dimensions": [
                {"name": "incident_id", "type": "string", "sql": "${TABLE}.incident_id"},
                {"name": "timestamp", "type": "time", "sql": "${TABLE}.timestamp"},
                {"name": "service", "type": "string", "sql": "${TABLE}.service"},
                {"name": "severity", "type": "string", "sql": "${TABLE}.severity"},
                {"name": "cpu_utilization", "type": "number", "sql": "${TABLE}.cpu_utilization"}
            ],
            "lookml_measures": [
                {"name": "total_incidents", "type": "count", "sql": "${TABLE}.incident_id"},
                {"name": "average_cpu_load", "type": "average", "sql": "${TABLE}.cpu_utilization"}
            ]
        }
        
        return {
            "summary": stats,
            "timeline": timeline,
            "distributions": distributions,
            "correlation_matrix": matrix,
            "looker_dataset": looker_ready_metadata
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Dashboard aggregation failed: {str(e)}")

@app.post("/chat")
def run_assistant_chat(request: ChatRequest):
    """
    Processes chat prompt with the current network graph as context, returning Gemini conclusions.
    """
    try:
        # Get active graph context
        graph = state.graph_builder.build_network_graph(
            state.incidents_df,
            state.jira_df,
            state.commits_df,
            state.metrics_df,
            state.support_df
        )
        
        response = state.assistant.generate_incident_explanation(graph, request.message)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gemini Chat Assistant failed: {str(e)}")

@app.get("/benchmark")
def run_gpu_benchmark(rows: Optional[int] = 5000):
    """
    Performs speed testing between standard CPU Pandas and cuDF on large datasets.
    """
    try:
        results = state.gpu_engine.benchmark_performance(row_scale=rows)
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Performance benchmarking failed: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    # Local runs will boot default uvicorn port
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
